/**
 * Nanobot Catalog & Order Portal Application Logic
 * Supports: Real PDF Photos, Double Layer vs Single Layer, MRP vs DP Wholesale, Capacity & Price Filtering
 */

// Application State
const AppState = {
  products: (typeof DEFAULT_PRODUCTS !== 'undefined') ? [...DEFAULT_PRODUCTS] : [],
  cart: [],
  activeLayerFilter: 'all', // 'all', 'double_layer', 'single_layer'
  selectedCapacityRange: 'all', // 'all', 'compact', '500', '750', '1000', 'large'
  selectedPriceRange: 'all', // 'all', 'under_300', '300_500', '500_800', '800_1200', 'above_1200'
  maxPriceLimit: 2500,
  searchQuery: '',
  sortBy: 'featured',
  pricingMode: 'dp', // 'dp' (Dealer Price) or 'mrp' (Retail Price)
  currency: 'INR',
  exchangeRate: 0.012,
  selectedProductForModal: null,
  whatsappNumber: '919876543210',
  customizer: {
    productId: 'nb-dl-therma',
    colorHex: '#1a1a1a',
    colorName: 'Matte Black',
    engravingText: 'YOUR BRAND HERE',
    brandingOptionId: 'laser'
  }
};

// Safe icon renderer
function safeCreateIcons() {
  try {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  } catch (err) {
    console.warn('Lucide icon rendering skipped:', err);
  }
}

// Currency Formatter
function formatPrice(amountInINR) {
  if (AppState.currency === 'USD') {
    const usd = (amountInINR * AppState.exchangeRate).toFixed(2);
    return `$${usd}`;
  }
  return `₹${amountInINR.toLocaleString('en-IN')}`;
}

// Helper: Extract numeric capacity in ml
function getCapacityNumber(capStr) {
  if (!capStr) return 500;
  const match = capStr.match(/(\d+)\s*ml/i);
  if (match) return parseInt(match[1]);
  if (capStr.includes('1.8') || capStr.includes('1800')) return 1800;
  if (capStr.includes('1.5') || capStr.includes('1500')) return 1500;
  if (capStr.includes('1.2') || capStr.includes('1200')) return 1200;
  if (capStr.includes('1 Litre') || capStr.includes('1000')) return 1000;
  return 500;
}

// Helper: Check if product matches capacity filter
function matchesCapacity(product, range) {
  if (range === 'all') return true;

  return product.variants.some(v => {
    const cap = getCapacityNumber(v.capacity);
    if (range === 'compact') return cap <= 460;
    if (range === '500') return cap >= 470 && cap <= 600;
    if (range === '750') return cap >= 650 && cap <= 850;
    if (range === '1000') return cap >= 900 && cap <= 1100;
    if (range === 'large') return cap >= 1200;
    return true;
  });
}

// Helper: Check if product matches price filter
function matchesPrice(product, priceRange) {
  const isDp = AppState.pricingMode === 'dp';
  
  return product.variants.some(v => {
    const price = isDp ? (v.dpPrice || v.wholesalePrice) : (v.mrp || v.price);
    
    if (priceRange === 'under_300') return price < 300;
    if (priceRange === '300_500') return price >= 300 && price <= 500;
    if (priceRange === '500_800') return price > 500 && price <= 800;
    if (priceRange === '800_1200') return price > 800 && price <= 1200;
    if (priceRange === 'above_1200') return price > 1200;
    
    return price <= AppState.maxPriceLimit;
  });
}

// Filter Control Handlers (Global)
window.setFilterLayer = function(layer) {
  AppState.activeLayerFilter = layer;
  updateFilterButtonsUI();
  renderProductGrid();
};

window.setFilterCapacity = function(range) {
  AppState.selectedCapacityRange = range;
  updateFilterButtonsUI();
  renderProductGrid();
};

window.setFilterPrice = function(range) {
  AppState.selectedPriceRange = range;
  updateFilterButtonsUI();
  renderProductGrid();
};

window.handlePriceSliderChange = function(val) {
  AppState.maxPriceLimit = parseInt(val);
  AppState.selectedPriceRange = 'all';
  const display = document.getElementById('price-slider-display');
  if (display) display.innerText = `Up to ${formatPrice(AppState.maxPriceLimit)}`;
  updateFilterButtonsUI();
  renderProductGrid();
};

window.handleSortChange = function(sortVal) {
  AppState.sortBy = sortVal;
  renderProductGrid();
};

window.resetFilters = function() {
  AppState.activeLayerFilter = 'all';
  AppState.selectedCapacityRange = 'all';
  AppState.selectedPriceRange = 'all';
  AppState.maxPriceLimit = 2500;
  AppState.searchQuery = '';
  AppState.sortBy = 'featured';

  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = '';
  const priceSlider = document.getElementById('price-range-slider');
  if (priceSlider) priceSlider.value = 2500;
  const sliderDisplay = document.getElementById('price-slider-display');
  if (sliderDisplay) sliderDisplay.innerText = `Up to ₹2,500`;
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) sortSelect.value = 'featured';

  updateFilterButtonsUI();
  renderProductGrid();
  showToast('Filters reset to show all models.');
};

function updateFilterButtonsUI() {
  // Layer buttons
  document.querySelectorAll('.filter-layer-btn').forEach(btn => {
    const val = btn.dataset.layer;
    if (val === AppState.activeLayerFilter) {
      btn.className = 'filter-layer-btn px-4 py-2 rounded-xl text-xs font-bold transition bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-lg shadow-sky-950/60 flex items-center gap-1.5 cursor-pointer';
    } else {
      btn.className = 'filter-layer-btn px-4 py-2 rounded-xl text-xs font-medium bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800 transition flex items-center gap-1.5 cursor-pointer';
    }
  });

  // Capacity buttons
  document.querySelectorAll('.filter-cap-btn').forEach(btn => {
    const val = btn.dataset.cap;
    if (val === AppState.selectedCapacityRange) {
      btn.className = 'filter-cap-btn px-3.5 py-1.5 rounded-xl text-xs font-bold transition bg-sky-500/20 text-sky-300 border border-sky-500/60 shadow-sm cursor-pointer';
    } else {
      btn.className = 'filter-cap-btn px-3.5 py-1.5 rounded-xl text-xs font-medium bg-slate-950 text-slate-400 hover:text-white hover:border-slate-700 border border-slate-800/80 transition cursor-pointer';
    }
  });

  // Price buttons
  document.querySelectorAll('.filter-price-btn').forEach(btn => {
    const val = btn.dataset.price;
    if (val === AppState.selectedPriceRange) {
      btn.className = 'filter-price-btn px-3.5 py-1.5 rounded-xl text-xs font-bold transition bg-emerald-500/20 text-emerald-300 border border-emerald-500/60 shadow-sm cursor-pointer';
    } else {
      btn.className = 'filter-price-btn px-3.5 py-1.5 rounded-xl text-xs font-medium bg-slate-950 text-slate-400 hover:text-white hover:border-slate-700 border border-slate-800/80 transition cursor-pointer';
    }
  });
}

// Render Products Grid
function renderProductGrid() {
  const container = document.getElementById('products-grid');
  const countLabel = document.getElementById('products-count');
  if (!container) return;

  const isDp = AppState.pricingMode === 'dp';

  let filtered = AppState.products.filter(p => {
    // 1. Layer Match
    if (AppState.activeLayerFilter !== 'all' && p.layerType !== AppState.activeLayerFilter) {
      return false;
    }

    // 2. Capacity Match
    if (!matchesCapacity(p, AppState.selectedCapacityRange)) {
      return false;
    }

    // 3. Price Match
    if (!matchesPrice(p, AppState.selectedPriceRange)) {
      return false;
    }

    // 4. Search Query Match
    if (AppState.searchQuery) {
      const q = AppState.searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchSku = p.sku.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      if (!matchName && !matchSku && !matchDesc) return false;
    }

    return true;
  });

  // Sorting
  if (AppState.sortBy === 'price_asc') {
    filtered.sort((a, b) => {
      const pa = isDp ? (a.variants[0].dpPrice || a.variants[0].wholesalePrice) : (a.variants[0].mrp || a.variants[0].price);
      const pb = isDp ? (b.variants[0].dpPrice || b.variants[0].wholesalePrice) : (b.variants[0].mrp || b.variants[0].price);
      return pa - pb;
    });
  } else if (AppState.sortBy === 'price_desc') {
    filtered.sort((a, b) => {
      const pa = isDp ? (a.variants[0].dpPrice || a.variants[0].wholesalePrice) : (a.variants[0].mrp || a.variants[0].price);
      const pb = isDp ? (b.variants[0].dpPrice || b.variants[0].wholesalePrice) : (b.variants[0].mrp || b.variants[0].price);
      return pb - pa;
    });
  } else if (AppState.sortBy === 'capacity_asc') {
    filtered.sort((a, b) => getCapacityNumber(a.variants[0].capacity) - getCapacityNumber(b.variants[0].capacity));
  }

  if (countLabel) {
    countLabel.innerText = `${filtered.length} Model${filtered.length === 1 ? '' : 's'} Found`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-16 text-center text-slate-500">
        <i data-lucide="filter-x" class="w-12 h-12 mx-auto mb-3 text-slate-600"></i>
        <h3 class="text-lg font-bold text-slate-300 mb-1">No bottles match your filters</h3>
        <p class="text-xs text-slate-400">Try selecting "All Sizes" or "All Budgets".</p>
        <button onclick="resetFilters()" class="mt-4 px-4 py-2 bg-sky-600 text-white rounded-xl text-xs font-bold hover:bg-sky-500 transition cursor-pointer">
          Reset Filters
        </button>
      </div>
    `;
    safeCreateIcons();
    return;
  }

  container.innerHTML = filtered.map(product => renderProductCard(product)).join('');
  safeCreateIcons();
}

function renderProductCard(product) {
  const isDpMode = AppState.pricingMode === 'dp';
  const defaultVariant = product.variants[0];
  const mrp = defaultVariant.mrp || defaultVariant.price;
  const dp = defaultVariant.dpPrice || defaultVariant.wholesalePrice;
  const marginPercent = Math.round(((mrp - dp) / mrp) * 100);

  const isDoubleLayer = product.layerType === 'double_layer' || product.hotHours > 0;

  return `
    <div class="glass-card rounded-2xl overflow-hidden flex flex-col group border border-slate-800/80 hover:border-sky-500/40 relative bg-slate-900/60" id="card-${product.id}">
      
      <!-- Badges -->
      <div class="absolute top-3 left-3 z-10 flex flex-col gap-1 items-start pointer-events-none">
        <span class="px-2.5 py-0.5 ${isDoubleLayer ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-sky-500/20 text-sky-300 border-sky-500/40'} border rounded-full text-[10px] font-bold flex items-center gap-1 backdrop-blur-md">
          <i data-lucide="${isDoubleLayer ? 'flame' : 'snowflake'}" class="w-3 h-3"></i>
          <span>${isDoubleLayer ? 'Double Layer (Vacuum)' : 'Single Layer (Fridge)'}</span>
        </span>
      </div>

      <!-- Bottle Visual Stage -->
      <div class="p-4 bg-gradient-to-b from-slate-950/60 to-slate-900/40 flex items-center justify-center relative cursor-pointer min-h-[220px]" onclick="openProductModal('${product.id}')">
        <div class="w-full h-48 relative flex items-center justify-center">
          <img src="${product.imageUrl}" alt="${product.name}" class="max-h-44 max-w-full object-contain drop-shadow-xl hover:scale-105 transition duration-300" onerror="this.src='images/products/nb-dl-therma.png'">
        </div>
        <div class="absolute bottom-1 right-3 text-[10px] text-slate-500 font-mono">${product.sku}</div>
      </div>

      <!-- Details Body -->
      <div class="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3 class="font-bold text-white text-sm leading-snug hover:text-sky-400 cursor-pointer transition mb-1" onclick="openProductModal('${product.id}')">
            ${product.name}
          </h3>
          <p class="text-[11px] text-slate-400 mb-2.5 line-clamp-1">${product.tagline}</p>

          <!-- Capacity Size Chips -->
          <div class="mb-3">
            <div class="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mb-1">Capacities:</div>
            <div class="flex flex-wrap gap-1" id="variants-${product.id}">
              ${product.variants.map((v, idx) => `
                <button type="button" 
                        onclick="selectCardVariant('${product.id}', ${idx})" 
                        class="variant-btn-${product.id} px-2 py-0.5 text-[11px] rounded-lg border transition font-medium cursor-pointer ${
                          idx === 0 
                            ? 'bg-sky-500/20 text-sky-300 border-sky-500/60 shadow-sm' 
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                        }"
                        data-index="${idx}">
                  ${v.capacity}
                </button>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Pricing (MRP & DP Price) & Action Bar -->
        <div class="pt-2.5 border-t border-slate-800/80">
          <div class="flex items-end justify-between mb-2.5">
            <div>
              <div class="flex items-center gap-1.5 text-[11px]">
                <span class="text-slate-400">MRP:</span>
                <span class="font-bold text-slate-300 ${isDpMode ? 'line-through' : 'text-sky-400 font-display text-sm'}" id="mrp-display-${product.id}">
                  ${formatPrice(mrp)}
                </span>
              </div>
              
              <div class="flex items-baseline gap-1.5 mt-0.5">
                <span class="text-[11px] text-slate-400 font-semibold">DP Rate:</span>
                <span class="text-base font-bold text-emerald-400 font-display" id="dp-display-${product.id}">
                  ${formatPrice(dp)}
                </span>
                <span class="text-[9px] text-emerald-300 font-bold bg-emerald-950/70 px-1 py-0.2 rounded border border-emerald-800/50">
                  ${marginPercent}% Margin
                </span>
              </div>
            </div>
            
            <button onclick="openProductCustomizer('${product.id}')" title="Test Laser Engraving" class="p-1.5 rounded-lg bg-slate-800 text-sky-400 hover:bg-sky-950 hover:text-sky-300 border border-slate-700 transition cursor-pointer">
              <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
            </button>
          </div>

          <!-- Add to Quote Button -->
          <button onclick="addCardToCart('${product.id}')" class="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-sky-950/50 transition active:scale-95 cursor-pointer">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
            <span>Add to Quotation</span>
          </button>
        </div>
      </div>

    </div>
  `;
}

// Card Variant Selection
const CardSelections = {};

window.selectCardVariant = function(productId, variantIndex) {
  if (!CardSelections[productId]) CardSelections[productId] = { variantIndex: 0 };
  CardSelections[productId].variantIndex = variantIndex;

  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  const buttons = document.querySelectorAll(`.variant-btn-${productId}`);
  buttons.forEach(btn => {
    const idx = parseInt(btn.dataset.index);
    if (idx === variantIndex) {
      btn.className = `variant-btn-${productId} px-2 py-0.5 text-[11px] rounded-lg border transition font-medium bg-sky-500/20 text-sky-300 border-sky-500/60 shadow-sm cursor-pointer`;
    } else {
      btn.className = `variant-btn-${productId} px-2 py-0.5 text-[11px] rounded-lg border transition font-medium bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 cursor-pointer`;
    }
  });

  const variant = product.variants[variantIndex];
  const mrpEl = document.getElementById(`mrp-display-${productId}`);
  const dpEl = document.getElementById(`dp-display-${productId}`);
  
  if (mrpEl) mrpEl.innerText = formatPrice(variant.mrp || variant.price);
  if (dpEl) dpEl.innerText = formatPrice(variant.dpPrice || variant.wholesalePrice);
};

window.addCardToCart = function(productId) {
  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  const selection = CardSelections[productId] || { variantIndex: 0 };
  const variant = product.variants[selection.variantIndex] || product.variants[0];

  const defaultQty = AppState.pricingMode === 'dp' ? (product.moqBulk || 25) : 1;
  const unitPrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);

  addToCart({
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    layerType: product.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: "Plain / Factory Finish",
    colorHex: "#cbd5e1",
    brandingId: 'none',
    customText: '',
    quantity: defaultQty,
    unitPrice: unitPrice,
    imageUrl: product.imageUrl
  });

  showToast(`Added ${product.name} (${variant.capacity}) to quotation!`);
};

// Cart System
function addToCart(item) {
  const existingIndex = AppState.cart.findIndex(i => 
    i.productId === item.productId &&
    i.capacity === item.capacity &&
    i.customText === item.customText
  );

  if (existingIndex > -1) {
    AppState.cart[existingIndex].quantity += item.quantity;
  } else {
    AppState.cart.push(item);
  }

  saveCartToStorage();
}

window.updateCartQuantity = function(index, newQty) {
  if (newQty <= 0) {
    AppState.cart.splice(index, 1);
  } else {
    AppState.cart[index].quantity = newQty;
  }
  saveCartToStorage();
  renderCartDrawer();
};

window.removeCartItem = function(index) {
  AppState.cart.splice(index, 1);
  saveCartToStorage();
  renderCartDrawer();
};

function saveCartToStorage() {
  try {
    localStorage.setItem('nanobot_cart', JSON.stringify(AppState.cart));
  } catch(e) {}
  updateCartBadge();
}

function updateCartBadge() {
  const badge = document.getElementById('cart-badge-count');
  const totalItems = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  if (badge) {
    badge.innerText = totalItems;
    badge.style.display = totalItems > 0 ? 'flex' : 'none';
  }
}

// Product Details Modal
window.openProductModal = function(productId) {
  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  AppState.selectedProductForModal = product;
  const modal = document.getElementById('product-modal');
  const modalBody = document.getElementById('product-modal-body');
  if (!modal || !modalBody) return;

  const isDoubleLayer = product.layerType === 'double_layer' || product.hotHours > 0;

  modalBody.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
      <div class="bg-slate-900 rounded-xl p-6 flex flex-col items-center justify-center border border-slate-800">
        <img src="${product.imageUrl}" alt="${product.name}" class="max-h-56 max-w-full object-contain drop-shadow-xl" onerror="this.src='images/products/nb-dl-therma.png'">
        <span class="text-xs text-slate-500 font-mono mt-3">${product.sku}</span>
      </div>

      <div>
        <div class="flex items-center gap-2 mb-1.5">
          <span class="text-[10px] font-bold px-2 py-0.5 rounded ${isDoubleLayer ? 'bg-amber-950 text-amber-300 border border-amber-800/40' : 'bg-blue-950 text-blue-300 border border-blue-800/40'}">
            ${isDoubleLayer ? 'Double Layer Vacuum (24h Cold / 18h Hot)' : 'Single Layer (Fridge Bottle)'}
          </span>
        </div>

        <h2 class="text-xl font-bold text-white font-display mb-1">${product.name}</h2>
        <p class="text-slate-300 text-xs mb-3 leading-relaxed">${product.description}</p>

        <!-- Technical Specs -->
        <div class="bg-slate-900/80 rounded-xl p-3 border border-slate-800 mb-4 space-y-1.5 text-xs">
          <div class="flex justify-between py-0.5 border-b border-slate-800">
            <span class="text-slate-400">Material Grade</span>
            <span class="text-white font-semibold">${product.steelGrade}</span>
          </div>
          <div class="flex justify-between py-0.5 border-b border-slate-800">
            <span class="text-slate-400">Lid Mechanism</span>
            <span class="text-white font-semibold">${product.lidType}</span>
          </div>
          <div class="flex justify-between py-0.5">
            <span class="text-slate-400">Recommended MOQ</span>
            <span class="text-white font-semibold">${product.moqBulk || 25} pcs (DP Wholesale)</span>
          </div>
        </div>

        <!-- Capacity Variant Buttons -->
        <div class="mb-4">
          <label class="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Select Size Variant:</label>
          <div class="grid grid-cols-2 gap-2" id="modal-variant-options">
            ${product.variants.map((v, idx) => `
              <button onclick="updateModalVariant(${idx})" class="p-2 rounded-xl border text-left transition cursor-pointer ${idx === 0 ? 'bg-sky-500/20 border-sky-500 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'} modal-var-btn" data-vindex="${idx}">
                <div class="font-bold text-xs">${v.capacity}</div>
                <div class="text-[10px] text-slate-400">MRP: ${formatPrice(v.mrp || v.price)}</div>
                <div class="text-xs text-emerald-400 font-semibold">DP: ${formatPrice(v.dpPrice || v.wholesalePrice)}</div>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Quantity & Add to Cart -->
        <div class="flex items-center gap-3">
          <div class="flex items-center bg-slate-900 border border-slate-700 rounded-xl p-1">
            <button onclick="adjustModalQty(-1)" class="w-7 h-7 rounded-lg bg-slate-800 text-white flex items-center justify-center cursor-pointer">-</button>
            <input type="number" id="modal-qty-input" value="${AppState.pricingMode === 'dp' ? (product.moqBulk || 25) : 1}" min="1" class="w-12 bg-transparent text-center text-white text-xs font-semibold focus:outline-none">
            <button onclick="adjustModalQty(1)" class="w-7 h-7 rounded-lg bg-slate-800 text-white flex items-center justify-center cursor-pointer">+</button>
          </div>

          <button onclick="addModalProductToCart()" class="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer">
            <i data-lucide="shopping-bag" class="w-4 h-4"></i>
            <span>Add to Quotation</span>
          </button>
        </div>

      </div>
    </div>
  `;

  modal.classList.remove('hidden');
  safeCreateIcons();
};

let modalSelectedVarIdx = 0;

window.updateModalVariant = function(idx) {
  modalSelectedVarIdx = idx;
  const buttons = document.querySelectorAll('.modal-var-btn');
  buttons.forEach(btn => {
    const vIdx = parseInt(btn.dataset.vindex);
    if (vIdx === idx) {
      btn.className = 'p-2 rounded-xl border text-left transition bg-sky-500/20 border-sky-500 text-white modal-var-btn cursor-pointer';
    } else {
      btn.className = 'p-2 rounded-xl border text-left transition bg-slate-900 border-slate-800 text-slate-300 modal-var-btn cursor-pointer';
    }
  });
};

window.adjustModalQty = function(delta) {
  const input = document.getElementById('modal-qty-input');
  if (!input) return;
  let val = parseInt(input.value) || 1;
  val = Math.max(1, val + delta);
  input.value = val;
};

window.addModalProductToCart = function() {
  const product = AppState.selectedProductForModal;
  if (!product) return;

  const variant = product.variants[modalSelectedVarIdx] || product.variants[0];
  const qtyInput = document.getElementById('modal-qty-input');
  const qty = parseInt(qtyInput ? qtyInput.value : 1) || 1;
  const unitPrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);

  addToCart({
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    layerType: product.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: "Plain / Factory Finish",
    colorHex: "#cbd5e1",
    brandingId: 'none',
    customText: '',
    quantity: qty,
    unitPrice: unitPrice,
    imageUrl: product.imageUrl
  });

  closeModal('product-modal');
  showToast(`Added ${qty}x ${product.name} to quotation!`);
};

// Laser Customizer Studio
function initCustomizer() {
  const modelSelect = document.getElementById('customizer-model-select');
  if (modelSelect) {
    modelSelect.innerHTML = AppState.products.map(p => `
      <option value="${p.id}">${p.name} (${p.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'})</option>
    `).join('');
    modelSelect.value = AppState.customizer.productId;
  }

  renderCustomizerColorSwatches();
  renderCustomizerBrandingOptions();
  renderCustomizerPreview();
}

window.openProductCustomizer = function(productId) {
  if (productId) {
    AppState.customizer.productId = productId;
    const modelSelect = document.getElementById('customizer-model-select');
    if (modelSelect) modelSelect.value = productId;
  }

  const customizerSection = document.getElementById('customizer-section');
  if (customizerSection) {
    customizerSection.scrollIntoView({ behavior: 'smooth' });
  }

  renderCustomizerColorSwatches();
  renderCustomizerPreview();
};

function renderCustomizerColorSwatches() {
  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const container = document.getElementById('customizer-color-swatches');
  if (!container || !prod || !prod.colors) return;

  container.innerHTML = prod.colors.map((c, i) => `
    <button type="button" 
            onclick="setCustomizerColor('${c.hex}', '${c.name}')" 
            title="${c.name}"
            style="background-color: ${c.hex};" 
            class="w-7 h-7 rounded-full border-2 transition transform hover:scale-110 shadow-sm cursor-pointer ${
              AppState.customizer.colorHex === c.hex ? 'border-sky-400 ring-2 ring-sky-400/40 scale-110' : 'border-slate-700'
            }">
    </button>
  `).join('');
}

function renderCustomizerBrandingOptions() {
  const container = document.getElementById('branding-options-container');
  if (!container) return;

  const brandingList = (typeof BRANDING_OPTIONS !== 'undefined') ? BRANDING_OPTIONS : [
    { id: "none", name: "Plain / Factory Finish", pricePerUnit: 0, moq: 1, desc: "Standard unbranded" },
    { id: "laser", name: "Laser Engraving", pricePerUnit: 25, moq: 10, desc: "Permanent crisp mark" }
  ];

  container.innerHTML = brandingList.map(opt => `
    <label class="flex items-start gap-2.5 p-2.5 rounded-xl border transition cursor-pointer ${
      AppState.customizer.brandingOptionId === opt.id ? 'bg-sky-950/40 border-sky-500 text-white' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
    }">
      <input type="radio" name="brandingOption" value="${opt.id}" ${AppState.customizer.brandingOptionId === opt.id ? 'checked' : ''} onchange="setBrandingOption('${opt.id}')" class="mt-0.5">
      <div class="flex-1 text-xs">
        <div class="flex items-center justify-between">
          <span class="font-bold text-white">${opt.name}</span>
          <span class="font-mono ${opt.pricePerUnit === 0 ? 'text-emerald-400' : 'text-sky-400'}">
            ${opt.pricePerUnit === 0 ? 'FREE' : `+${formatPrice(opt.pricePerUnit)}/unit`}
          </span>
        </div>
        <p class="text-[10px] text-slate-400 mt-0.5">${opt.desc} (Min Qty: ${opt.moq} pcs)</p>
      </div>
    </label>
  `).join('');
}

window.setCustomizerColor = function(hex, name) {
  AppState.customizer.colorHex = hex;
  AppState.customizer.colorName = name;
  renderCustomizerColorSwatches();
  renderCustomizerPreview();
};

window.setBrandingOption = function(optId) {
  AppState.customizer.brandingOptionId = optId;
  renderCustomizerBrandingOptions();
  renderCustomizerPreview();
};

function renderCustomizerPreview() {
  const canvas = document.getElementById('customizer-canvas');
  if (!canvas) return;

  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const text = AppState.customizer.engravingText;

  canvas.innerHTML = `
    <div class="relative w-full h-full flex flex-col items-center justify-center p-4">
      <img src="${prod.imageUrl}" class="max-h-64 max-w-full object-contain drop-shadow-xl" onerror="this.src='images/products/nb-dl-therma.png'">
      <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <div class="bg-slate-900/90 px-3 py-1 rounded-lg border border-sky-400/50 backdrop-blur-md shadow-xl text-center">
          <div class="font-bold text-xs tracking-widest text-sky-300 font-mono uppercase">${escapeHtml(text)}</div>
          <div class="text-[8px] text-slate-400 font-mono tracking-wider">PERMANENT LASER MARK</div>
        </div>
      </div>
    </div>
  `;
}

window.handleCustomizerTextChange = function(val) {
  AppState.customizer.engravingText = val;
  renderCustomizerPreview();
};

window.addCustomizerToCart = function() {
  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const brandingList = (typeof BRANDING_OPTIONS !== 'undefined') ? BRANDING_OPTIONS : [];
  const branding = brandingList.find(b => b.id === AppState.customizer.brandingOptionId) || { id: 'laser', name: 'Laser Engraving', pricePerUnit: 25, moq: 10 };
  const variant = prod.variants[0];
  const defaultQty = Math.max(branding.moq || 1, AppState.pricingMode === 'dp' ? (prod.moqBulk || 25) : 1);

  const basePrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);
  const finalUnitPrice = basePrice + (branding.pricePerUnit || 0);

  addToCart({
    productId: prod.id,
    productName: prod.name,
    sku: prod.sku,
    layerType: prod.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: AppState.customizer.colorName,
    colorHex: AppState.customizer.colorHex,
    brandingId: branding.id,
    brandingName: branding.name,
    customText: AppState.customizer.engravingText,
    quantity: defaultQty,
    unitPrice: finalUnitPrice,
    imageUrl: prod.imageUrl
  });

  showToast(`Added custom engraved ${prod.name} to Quotation!`);
};

// Quotation Drawer & WhatsApp Generator
window.openCartDrawer = function() {
  renderCartDrawer();
  const drawer = document.getElementById('cart-drawer');
  if (drawer) drawer.classList.remove('translate-x-full');
};

window.closeCartDrawer = function() {
  const drawer = document.getElementById('cart-drawer');
  if (drawer) drawer.classList.add('translate-x-full');
};

function renderCartDrawer() {
  const itemsContainer = document.getElementById('cart-items-container');
  const subtotalEl = document.getElementById('cart-subtotal');
  const discountEl = document.getElementById('cart-discount');
  const totalEl = document.getElementById('cart-total');
  const tierInfoEl = document.getElementById('cart-tier-info');
  if (!itemsContainer) return;

  if (AppState.cart.length === 0) {
    itemsContainer.innerHTML = `
      <div class="py-16 text-center text-slate-500">
        <i data-lucide="shopping-bag" class="w-12 h-12 mx-auto mb-2 text-slate-600"></i>
        <h4 class="text-sm font-bold text-slate-300">Your quotation list is empty</h4>
        <p class="text-[11px] text-slate-400 mt-0.5">Select bottles from catalog to build an estimate.</p>
      </div>
    `;
    if (subtotalEl) subtotalEl.innerText = formatPrice(0);
    if (discountEl) discountEl.innerText = formatPrice(0);
    if (totalEl) totalEl.innerText = formatPrice(0);
    if (tierInfoEl) tierInfoEl.innerHTML = '';
    safeCreateIcons();
    return;
  }

  const totalUnits = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  let subtotal = AppState.cart.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);

  const tierList = (typeof WHOLESALE_TIERS !== 'undefined') ? WHOLESALE_TIERS : [
    { minQty: 1, maxQty: 9, label: "Retail Tier (MRP)", discountPercent: 0, tag: "MRP Rate" },
    { minQty: 10, maxQty: 49, label: "Dealer Base Tier (DP Rate)", discountPercent: 0, tag: "Dealer Price (DP)" },
    { minQty: 50, maxQty: 199, label: "Corporate Bulk Tier", discountPercent: 10, tag: "10% Extra on DP" },
    { minQty: 200, maxQty: 499, label: "Super Stockist Tier", discountPercent: 15, tag: "15% Extra on DP" },
    { minQty: 500, maxQty: 999999, label: "Factory Direct OEM/ODM", discountPercent: 22, tag: "Best Factory Rate" }
  ];

  let currentTier = tierList[0];
  for (let tier of tierList) {
    if (totalUnits >= tier.minQty) currentTier = tier;
  }

  const discountAmount = Math.round(subtotal * (currentTier.discountPercent / 100));
  const finalTotal = subtotal - discountAmount;

  if (tierInfoEl) {
    tierInfoEl.innerHTML = `
      <div class="p-2.5 bg-sky-950/60 border border-sky-800/60 rounded-xl mb-3 text-xs flex items-center justify-between">
        <div class="flex items-center gap-1.5">
          <i data-lucide="award" class="w-4 h-4 text-sky-400"></i>
          <span class="text-sky-200 font-semibold">${currentTier.label} (${totalUnits} Pcs)</span>
        </div>
        <span class="px-2 py-0.2 bg-emerald-500/20 text-emerald-300 font-bold rounded text-[10px]">${currentTier.tag}</span>
      </div>
    `;
  }

  itemsContainer.innerHTML = AppState.cart.map((item, index) => `
    <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 flex gap-3 items-start">
      <div class="w-12 h-16 shrink-0 bg-slate-950 rounded-lg p-1 flex items-center justify-center">
        <img src="${item.imageUrl}" alt="${item.productName}" class="max-h-14 max-w-full object-contain" onerror="this.src='images/products/nb-dl-therma.png'">
      </div>

      <div class="flex-1 min-w-0">
        <div class="flex justify-between items-start">
          <h4 class="text-xs font-bold text-white truncate">${item.productName}</h4>
          <button onclick="removeCartItem(${index})" class="text-slate-500 hover:text-red-400 p-1 cursor-pointer" title="Remove">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>

        <div class="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
          <span class="font-bold text-slate-300">${item.capacity}</span> • 
          <span class="${item.layerType === 'double_layer' ? 'text-amber-400' : 'text-sky-400'}">
            ${item.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'}
          </span>
        </div>

        ${item.customText ? `
          <div class="text-[10px] text-sky-400 font-mono mt-0.5">Laser: "${escapeHtml(item.customText)}"</div>
        ` : ''}

        <div class="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800">
          <div class="flex items-center bg-slate-950 border border-slate-800 rounded-lg">
            <button onclick="updateCartQuantity(${index}, ${item.quantity - 1})" class="w-5 h-5 flex items-center justify-center text-slate-400 cursor-pointer">-</button>
            <input type="number" value="${item.quantity}" onchange="updateCartQuantity(${index}, parseInt(this.value)||1)" min="1" class="w-10 bg-transparent text-center text-xs text-white font-semibold focus:outline-none">
            <button onclick="updateCartQuantity(${index}, ${item.quantity + 1})" class="w-5 h-5 flex items-center justify-center text-slate-400 cursor-pointer">+</button>
          </div>
          <div class="text-right">
            <div class="text-xs font-bold text-white">${formatPrice(item.unitPrice * item.quantity)}</div>
          </div>
        </div>
      </div>
    </div>
  `).join('');

  if (subtotalEl) subtotalEl.innerText = formatPrice(subtotal);
  if (discountEl) discountEl.innerText = `-${formatPrice(discountAmount)}`;
  if (totalEl) totalEl.innerText = formatPrice(finalTotal);

  safeCreateIcons();
}

// WhatsApp Order
window.generateWhatsAppOrder = function() {
  if (AppState.cart.length === 0) {
    showToast('Your quotation list is empty!');
    return;
  }

  const clientName = document.getElementById('client-name')?.value.trim() || 'Client';
  const clientCompany = document.getElementById('client-company')?.value.trim() || '';

  const totalUnits = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  let subtotal = AppState.cart.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);

  const tierList = (typeof WHOLESALE_TIERS !== 'undefined') ? WHOLESALE_TIERS : [];
  let currentTier = tierList[0] || { tag: "DP Rate", discountPercent: 0 };
  for (let tier of tierList) {
    if (totalUnits >= tier.minQty) currentTier = tier;
  }

  const discountAmount = Math.round(subtotal * (currentTier.discountPercent / 100));
  const finalTotal = subtotal - discountAmount;

  let msg = `*✨ NANOBOT STAINLESS STEEL BOTTLE QUOTATION ✨*\n`;
  msg += `-------------------------------------------\n`;
  msg += `👤 *Client:* ${clientName} ${clientCompany ? `(${clientCompany})` : ''}\n`;
  msg += `📅 *Date:* ${new Date().toLocaleDateString()}\n`;
  msg += `-------------------------------------------\n`;
  msg += `*SELECTED MODELS:*\n\n`;

  AppState.cart.forEach((item, i) => {
    const layer = item.layerType === 'double_layer' ? 'Double Layer Vacuum' : 'Single Layer Fridge';
    msg += `${i + 1}. *${item.productName}* [${item.sku}]\n`;
    msg += `   • Size: ${item.capacity} (${layer})\n`;
    if (item.mrp) msg += `   • MRP: ${formatPrice(item.mrp)} | Rate: ${formatPrice(item.unitPrice)}\n`;
    if (item.customText) msg += `   • Laser Engraving: "${item.customText}"\n`;
    msg += `   • Qty: ${item.quantity} pcs = ${formatPrice(item.unitPrice * item.quantity)}\n\n`;
  });

  msg += `-------------------------------------------\n`;
  msg += `📦 *Total Quantity:* ${totalUnits} Units\n`;
  msg += `💰 *Subtotal:* ${formatPrice(subtotal)}\n`;
  if (discountAmount > 0) {
    msg += `🎉 *Volume Discount (${currentTier.tag}):* -${formatPrice(discountAmount)}\n`;
  }
  msg += `🏷️ *Estimated Total:* ${formatPrice(finalTotal)}\n`;

  const waUrl = `https://wa.me/${AppState.whatsappNumber}?text=${encodeURIComponent(msg)}`;
  window.open(waUrl, '_blank');
};

// PDF Quotation
window.downloadPdfQuotation = function() {
  if (AppState.cart.length === 0) {
    showToast('Add bottles to quotation first!');
    return;
  }

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const clientName = document.getElementById('client-name')?.value.trim() || 'Valued Customer';
    const clientCompany = document.getElementById('client-company')?.value.trim() || 'N/A';

    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, 210, 36, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text('NANOBOT', 14, 18);

    doc.setFontSize(9);
    doc.setTextColor(56, 189, 248);
    doc.text('STAINLESS STEEL BOTTLE MANUFACTURER', 14, 25);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(8);
    doc.text('Proforma Estimate', 150, 18);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 150, 24);

    doc.setTextColor(30, 41, 59);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('Quotation For:', 14, 46);
    doc.setFont('helvetica', 'normal');
    doc.text(`Client: ${clientName} (${clientCompany})`, 14, 52);

    let y = 65;
    doc.setFillColor(241, 245, 249);
    doc.rect(14, y - 5, 182, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.text('SN', 16, y);
    doc.text('Model Description', 28, y);
    doc.text('Capacity', 100, y);
    doc.text('Rate', 135, y);
    doc.text('Qty', 160, y);
    doc.text('Total', 180, y);

    doc.setFont('helvetica', 'normal');
    y += 7;

    let subtotal = 0;
    let totalQty = 0;

    AppState.cart.forEach((item, idx) => {
      const itemTotal = item.unitPrice * item.quantity;
      subtotal += itemTotal;
      totalQty += item.quantity;

      doc.text(`${idx + 1}`, 16, y);
      doc.text(`${item.productName}`, 28, y);
      doc.text(`${item.capacity}`, 100, y);
      doc.text(`${item.unitPrice}`, 135, y);
      doc.text(`${item.quantity}`, 160, y);
      doc.text(`${itemTotal}`, 180, y);

      y += 7;
    });

    y += 5;
    doc.line(14, y, 196, y);
    y += 7;

    doc.setFont('helvetica', 'bold');
    doc.text(`Total Units: ${totalQty}`, 14, y);
    doc.text(`Grand Total: ${formatPrice(subtotal)}`, 140, y);

    doc.save(`Nanobot_Estimate_${Date.now().toString().slice(-4)}.pdf`);
    showToast('PDF estimate downloaded!');
  } catch (err) {
    console.error('PDF error:', err);
    window.print();
  }
};

// Admin / Price Manager Modal
window.openAdminModal = function() {
  const modal = document.getElementById('admin-modal');
  if (!modal) return;
  renderAdminProductsList();
  modal.classList.remove('hidden');
};

function renderAdminProductsList() {
  const container = document.getElementById('admin-products-list');
  if (!container) return;

  container.innerHTML = AppState.products.map((p, idx) => `
    <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <img src="${p.imageUrl}" class="w-10 h-10 object-contain">
        <div>
          <h4 class="font-bold text-white text-xs">${p.name}</h4>
          <span class="text-[10px] text-sky-400 font-mono">${p.sku}</span> • 
          <span class="text-[10px] font-semibold ${p.layerType === 'double_layer' ? 'text-amber-400' : 'text-sky-400'}">
            ${p.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'}
          </span>
        </div>
      </div>
      <div class="text-right text-xs">
        <div class="text-slate-400">MRP: <span class="text-white font-bold">${formatPrice(p.variants[0].mrp || p.variants[0].price)}</span></div>
        <div class="text-emerald-400">DP: <span class="font-bold">${formatPrice(p.variants[0].dpPrice || p.variants[0].wholesalePrice)}</span></div>
      </div>
    </div>
  `).join('');

  safeCreateIcons();
}

window.exportCatalogJSON = function() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(AppState.products, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `Nanobot_Catalog_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
};

window.resetToDefaultCatalog = function() {
  AppState.products = (typeof DEFAULT_PRODUCTS !== 'undefined') ? [...DEFAULT_PRODUCTS] : [];
  renderAdminProductsList();
  renderProductGrid();
  showToast('Reset to default catalog lineup.');
};

window.closeModal = function(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('hidden');
};

function showToast(message) {
  const toast = document.getElementById('toast-notification');
  const toastMsg = document.getElementById('toast-message');
  if (!toast || !toastMsg) return;

  toastMsg.innerText = message;
  toast.classList.remove('hidden');

  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
  });
}

// Global Event Delegation (Guarantees every click on tabs/chips works reliably)
document.addEventListener('click', (e) => {
  // 1. Layer Tabs
  const layerBtn = e.target.closest('.filter-layer-btn');
  if (layerBtn) {
    const layer = layerBtn.dataset.layer;
    if (layer) setFilterLayer(layer);
    return;
  }

  // 2. Capacity Chips
  const capBtn = e.target.closest('.filter-cap-btn');
  if (capBtn) {
    const cap = capBtn.dataset.cap;
    if (cap) setFilterCapacity(cap);
    return;
  }

  // 3. Price Chips
  const priceBtn = e.target.closest('.filter-price-btn');
  if (priceBtn) {
    const price = priceBtn.dataset.price;
    if (price) setFilterPrice(price);
    return;
  }
});

function initEventListeners() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.searchQuery = e.target.value.trim();
      renderProductGrid();
    });
  }

  const mrpBtn = document.getElementById('btn-mode-mrp');
  const dpBtn = document.getElementById('btn-mode-dp');

  if (mrpBtn && dpBtn) {
    mrpBtn.addEventListener('click', () => {
      AppState.pricingMode = 'mrp';
      mrpBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition bg-sky-500 text-white shadow-sm cursor-pointer';
      dpBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition cursor-pointer';
      renderProductGrid();
    });

    dpBtn.addEventListener('click', () => {
      AppState.pricingMode = 'dp';
      dpBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition bg-emerald-600 text-white shadow-sm cursor-pointer';
      mrpBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition cursor-pointer';
      renderProductGrid();
    });
  }

  const customizerSelect = document.getElementById('customizer-model-select');
  if (customizerSelect) {
    customizerSelect.addEventListener('change', (e) => {
      openProductCustomizer(e.target.value);
    });
  }
}

// Initial Boot on Load
function startApp() {
  if (typeof DEFAULT_PRODUCTS !== 'undefined' && DEFAULT_PRODUCTS.length > 0) {
    AppState.products = [...DEFAULT_PRODUCTS];
  }

  try {
    const savedCart = localStorage.getItem('nanobot_cart');
    if (savedCart) AppState.cart = JSON.parse(savedCart);
  } catch(e) {}

  renderProductGrid();
  updateFilterButtonsUI();
  updateCartBadge();
  initEventListeners();
  initCustomizer();
  safeCreateIcons();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startApp);
} else {
  startApp();
}
