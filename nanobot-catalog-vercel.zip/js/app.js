/**
 * Nanobot Catalog & Quotation Portal Application Logic
 * Supports: Real Images, Double Layer / Single Layer, MRP & DP Pricing, Simple Capacity & Price Filters
 */

// Application State
const AppState = {
  products: [],
  cart: [],
  activeLayerFilter: 'all', // 'all', 'double_layer', 'single_layer'
  activeCategory: 'all',
  searchQuery: '',
  selectedCapacityRange: 'all', // 'all', 'compact', '500', '750', '1000', 'large'
  selectedPriceRange: 'all',    // 'all', 'under_300', '300_500', '500_800', '800_1200', 'above_1200'
  maxPriceLimit: 2500,
  sortBy: 'featured',           // 'featured', 'price_asc', 'price_desc', 'capacity_asc'
  pricingMode: 'dp',            // 'mrp' (Retail) or 'dp' (Dealer Price)
  currency: 'INR',
  exchangeRate: 0.012,
  selectedProductForModal: null,
  comparisonIds: [],
  whatsappNumber: '919876543210',
  customizer: {
    productId: 'nb-dl-therma',
    colorHex: '#1a1a1a',
    colorName: 'Matte Black',
    engravingText: 'YOUR BRAND HERE',
    fontFamily: 'Space Grotesk',
    brandingOptionId: 'laser',
    textColor: '#e2e8f0',
    logoDataUrl: null
  }
};

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  loadSavedData();
  renderProductGrid();
  updateCartBadge();
  initEventListeners();
  initCustomizer();
  lucide.createIcons();
  checkUrlParamsForCart();
});

// Load from LocalStorage
function loadSavedData() {
  const savedProducts = localStorage.getItem('nanobot_custom_products');
  if (savedProducts) {
    try {
      AppState.products = JSON.parse(savedProducts);
    } catch (e) {
      AppState.products = [...DEFAULT_PRODUCTS];
    }
  } else {
    AppState.products = [...DEFAULT_PRODUCTS];
  }

  const savedCart = localStorage.getItem('nanobot_cart');
  if (savedCart) {
    try {
      AppState.cart = JSON.parse(savedCart);
    } catch (e) {
      AppState.cart = [];
    }
  }
}

function saveCartToStorage() {
  localStorage.setItem('nanobot_cart', JSON.stringify(AppState.cart));
  updateCartBadge();
}

function saveProductsToStorage() {
  localStorage.setItem('nanobot_custom_products', JSON.stringify(AppState.products));
}

// Currency Formatter
function formatPrice(amountInINR) {
  if (AppState.currency === 'USD') {
    const usd = (amountInINR * AppState.exchangeRate).toFixed(2);
    return `$${usd}`;
  }
  return `₹${amountInINR.toLocaleString('en-IN')}`;
}

// Helper: Extract numeric capacity in ml
function getCapacityNumber(capStr) {
  const match = capStr.match(/(\d+)\s*ml/i);
  return match ? parseInt(match[1]) : 500;
}

// Helper: Check if product matches capacity filter
function matchesCapacity(product, range) {
  if (range === 'all') return true;

  return product.variants.some(v => {
    const cap = getCapacityNumber(v.capacity);
    if (range === 'compact') return cap <= 460;
    if (range === '500') return cap >= 470 && cap <= 600;
    if (range === '750') return cap >= 650 && cap <= 850;
    if (range === '1000') return cap >= 900 && cap <= 1100;
    if (range === 'large') return cap >= 1200;
    return true;
  });
}

// Helper: Check if product matches price filter
function matchesPrice(product, priceRange) {
  const isDp = AppState.pricingMode === 'dp';
  
  return product.variants.some(v => {
    const price = isDp ? (v.dpPrice || v.wholesalePrice) : (v.mrp || v.price);
    
    if (priceRange === 'under_300') return price < 300;
    if (priceRange === '300_500') return price >= 300 && price <= 500;
    if (priceRange === '500_800') return price > 500 && price <= 800;
    if (priceRange === '800_1200') return price > 800 && price <= 1200;
    if (priceRange === 'above_1200') return price > 1200;
    
    // Check max price slider limit
    return price <= AppState.maxPriceLimit;
  });
}

// Filter Control Handlers
function setFilterLayer(layer) {
  AppState.activeLayerFilter = layer;
  updateFilterButtonsUI();
  renderProductGrid();
}

function setFilterCapacity(range) {
  AppState.selectedCapacityRange = range;
  updateFilterButtonsUI();
  renderProductGrid();
}

function setFilterPrice(range) {
  AppState.selectedPriceRange = range;
  updateFilterButtonsUI();
  renderProductGrid();
}

function handlePriceSliderChange(val) {
  AppState.maxPriceLimit = parseInt(val);
  AppState.selectedPriceRange = 'all'; // reset chip when slider moves
  const display = document.getElementById('price-slider-display');
  if (display) display.innerText = `Up to ${formatPrice(AppState.maxPriceLimit)}`;
  updateFilterButtonsUI();
  renderProductGrid();
}

function handleSortChange(sortVal) {
  AppState.sortBy = sortVal;
  renderProductGrid();
}

function updateFilterButtonsUI() {
  // Layer buttons
  document.querySelectorAll('.filter-layer-btn').forEach(btn => {
    const val = btn.dataset.layer;
    if (val === AppState.activeLayerFilter) {
      btn.className = 'filter-layer-btn px-4 py-2 rounded-xl text-xs font-bold transition bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-lg shadow-sky-950/60 flex items-center gap-1.5';
    } else {
      btn.className = 'filter-layer-btn px-4 py-2 rounded-xl text-xs font-medium bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800 transition flex items-center gap-1.5';
    }
  });

  // Capacity buttons
  document.querySelectorAll('.filter-cap-btn').forEach(btn => {
    const val = btn.dataset.cap;
    if (val === AppState.selectedCapacityRange) {
      btn.className = 'filter-cap-btn px-3.5 py-1.5 rounded-xl text-xs font-bold transition bg-sky-500/20 text-sky-300 border border-sky-500/60 shadow-sm';
    } else {
      btn.className = 'filter-cap-btn px-3.5 py-1.5 rounded-xl text-xs font-medium bg-slate-950 text-slate-400 hover:text-white hover:border-slate-700 border border-slate-800/80 transition';
    }
  });

  // Price buttons
  document.querySelectorAll('.filter-price-btn').forEach(btn => {
    const val = btn.dataset.price;
    if (val === AppState.selectedPriceRange) {
      btn.className = 'filter-price-btn px-3.5 py-1.5 rounded-xl text-xs font-bold transition bg-emerald-500/20 text-emerald-300 border border-emerald-500/60 shadow-sm';
    } else {
      btn.className = 'filter-price-btn px-3.5 py-1.5 rounded-xl text-xs font-medium bg-slate-950 text-slate-400 hover:text-white hover:border-slate-700 border border-slate-800/80 transition';
    }
  });
}

function resetFilters() {
  AppState.activeLayerFilter = 'all';
  AppState.selectedCapacityRange = 'all';
  AppState.selectedPriceRange = 'all';
  AppState.maxPriceLimit = 2500;
  AppState.searchQuery = '';
  AppState.sortBy = 'featured';

  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = '';
  const priceSlider = document.getElementById('price-range-slider');
  if (priceSlider) priceSlider.value = 2500;
  const sliderDisplay = document.getElementById('price-slider-display');
  if (sliderDisplay) sliderDisplay.innerText = `Up to ₹2,500`;
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) sortSelect.value = 'featured';

  updateFilterButtonsUI();
  renderProductGrid();
  showToast('Filters reset to show all models.');
}

// Render Products Grid
function renderProductGrid() {
  const container = document.getElementById('products-grid');
  const countLabel = document.getElementById('products-count');
  if (!container) return;

  const isDp = AppState.pricingMode === 'dp';

  let filtered = AppState.products.filter(p => {
    // 1. Layer Match
    if (AppState.activeLayerFilter !== 'all' && p.layerType !== AppState.activeLayerFilter) {
      return false;
    }

    // 2. Capacity Match
    if (!matchesCapacity(p, AppState.selectedCapacityRange)) {
      return false;
    }

    // 3. Price Match
    if (!matchesPrice(p, AppState.selectedPriceRange)) {
      return false;
    }

    // 4. Search Query Match
    if (AppState.searchQuery) {
      const q = AppState.searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchSku = p.sku.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      if (!matchName && !matchSku && !matchDesc) return false;
    }

    return true;
  });

  // Sorting
  if (AppState.sortBy === 'price_asc') {
    filtered.sort((a, b) => {
      const pa = isDp ? (a.variants[0].dpPrice || a.variants[0].wholesalePrice) : (a.variants[0].mrp || a.variants[0].price);
      const pb = isDp ? (b.variants[0].dpPrice || b.variants[0].wholesalePrice) : (b.variants[0].mrp || b.variants[0].price);
      return pa - pb;
    });
  } else if (AppState.sortBy === 'price_desc') {
    filtered.sort((a, b) => {
      const pa = isDp ? (a.variants[0].dpPrice || a.variants[0].wholesalePrice) : (a.variants[0].mrp || a.variants[0].price);
      const pb = isDp ? (b.variants[0].dpPrice || b.variants[0].wholesalePrice) : (b.variants[0].mrp || b.variants[0].price);
      return pb - pa;
    });
  } else if (AppState.sortBy === 'capacity_asc') {
    filtered.sort((a, b) => getCapacityNumber(a.variants[0].capacity) - getCapacityNumber(b.variants[0].capacity));
  }

  if (countLabel) {
    countLabel.innerText = `${filtered.length} Model${filtered.length === 1 ? '' : 's'} Found`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-16 text-center text-slate-500">
        <i data-lucide="filter-x" class="w-16 h-16 mx-auto mb-4 text-slate-600"></i>
        <h3 class="text-xl font-bold text-slate-300 mb-1">No bottles match your exact filters</h3>
        <p class="text-sm text-slate-400">Try expanding your price range or selecting "All Capacities".</p>
        <button onclick="resetFilters()" class="mt-4 px-5 py-2.5 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-xl text-xs font-bold hover:from-sky-400 hover:to-blue-500 shadow-md">
          Reset All Filters
        </button>
      </div>
    `;
    lucide.createIcons();
    return;
  }

  container.innerHTML = filtered.map(product => renderProductCard(product)).join('');
  lucide.createIcons();
}

function renderProductCard(product) {
  const isDpMode = AppState.pricingMode === 'dp';
  const defaultVariant = product.variants[0];
  const defaultColor = product.colors && product.colors.length > 0 ? product.colors[0] : { name: "Stainless Steel", hex: "#cbd5e1" };
  const isComparing = AppState.comparisonIds.includes(product.id);

  const mrp = defaultVariant.mrp || defaultVariant.price;
  const dp = defaultVariant.dpPrice || defaultVariant.wholesalePrice;
  const marginPercent = Math.round(((mrp - dp) / mrp) * 100);

  const isDoubleLayer = product.layerType === 'double_layer' || product.hotHours > 0;

  return `
    <div class="glass-card rounded-2xl overflow-hidden flex flex-col group border border-slate-800/80 hover:border-sky-500/40 relative" id="card-${product.id}">
      
      <!-- Badges -->
      <div class="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
        <span class="px-2.5 py-1 ${isDoubleLayer ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' : 'bg-sky-500/20 text-sky-300 border-sky-500/30'} border rounded-full text-[11px] font-bold flex items-center gap-1 backdrop-blur-md">
          <i data-lucide="${isDoubleLayer ? 'flame' : 'snowflake'}" class="w-3.5 h-3.5 ${isDoubleLayer ? 'text-amber-400' : 'text-sky-400'}"></i>
          <span>${isDoubleLayer ? 'Double Layer (Vacuum)' : 'Single Layer (Fridge)'}</span>
        </span>
        ${product.isBestseller ? `
          <span class="px-2.5 py-0.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-full text-[10px] font-bold tracking-wider uppercase shadow-sm">
            ★ Bestseller
          </span>` : ''
        }
      </div>

      <!-- Quick Compare Button -->
      <button onclick="toggleCompare('${product.id}')" title="Add to comparison" class="absolute top-3 right-3 z-10 p-2 rounded-xl backdrop-blur-md transition ${isComparing ? 'bg-sky-500 text-white shadow-lg' : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'}">
        <i data-lucide="layers" class="w-4 h-4"></i>
      </button>

      <!-- Bottle Visual Stage -->
      <div class="p-6 pb-2 bg-gradient-to-b from-slate-900/40 to-slate-950/80 flex items-center justify-center relative cursor-pointer min-h-[260px]" onclick="openProductModal('${product.id}')">
        <div class="w-36 h-56 bottle-mockup-wrapper relative flex items-center justify-center" id="bottle-render-${product.id}">
          ${product.imageUrl ? `
            <img src="${product.imageUrl}" alt="${product.name}" class="max-h-52 max-w-full object-contain drop-shadow-2xl hover:scale-105 transition duration-300">
          ` : `
            <div class="text-center p-4 text-xs text-slate-500">${product.name}</div>
          `}
        </div>
        <div class="absolute bottom-2 text-[11px] text-slate-500 tracking-wider font-mono">${product.sku}</div>
      </div>

      <!-- Details Body -->
      <div class="p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 class="font-bold text-white text-base leading-snug hover:text-sky-400 cursor-pointer transition mb-1" onclick="openProductModal('${product.id}')">
            ${product.name}
          </h3>
          <p class="text-xs text-slate-400 mb-3 line-clamp-1">${product.tagline}</p>

          <!-- Steel Spec Chip -->
          <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 text-xs font-mono mb-3 border border-slate-700/50">
            <i data-lucide="shield-check" class="w-3.5 h-3.5 text-sky-400"></i>
            <span>${product.steelGrade}</span>
          </div>

          <!-- Capacity Variant Chips -->
          <div class="mb-3">
            <div class="text-[11px] text-slate-400 uppercase font-semibold tracking-wider mb-1.5">Capacity Size:</div>
            <div class="flex flex-wrap gap-1.5" id="variants-${product.id}">
              ${product.variants.map((v, idx) => `
                <button type="button" 
                        onclick="selectCardVariant('${product.id}', ${idx})" 
                        class="variant-btn-${product.id} px-2.5 py-1 text-xs rounded-lg border transition font-medium ${
                          idx === 0 
                            ? 'bg-sky-500/20 text-sky-300 border-sky-500/60 shadow-sm' 
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }"
                        data-index="${idx}">
                  ${v.capacity}
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Color Swatches (if available) -->
          ${product.colors && product.colors.length > 0 ? `
            <div class="mb-4">
              <div class="text-[11px] text-slate-400 uppercase font-semibold tracking-wider mb-1.5 flex items-center justify-between">
                <span>Color Finishes (${product.colors.length}):</span>
                <span class="text-slate-300 font-normal" id="color-name-${product.id}">${defaultColor.name}</span>
              </div>
              <div class="flex items-center gap-2 flex-wrap">
                ${product.colors.map((c, cIdx) => `
                  <button type="button" 
                          onclick="selectCardColor('${product.id}', ${cIdx})" 
                          title="${c.name}"
                          style="background-color: ${c.hex};" 
                          class="w-6 h-6 rounded-full border-2 transition transform hover:scale-110 shadow-sm ${
                            cIdx === 0 ? 'border-sky-400 ring-2 ring-sky-400/30 scale-110' : 'border-slate-700'
                          } color-btn-${product.id}"
                          data-cindex="${cIdx}">
                  </button>
                `).join('')}
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Pricing (MRP & DP Price) & Action Bar -->
        <div class="pt-3 border-t border-slate-800/80">
          <div class="flex items-end justify-between mb-3">
            <div>
              <div class="flex items-center gap-2 text-xs">
                <span class="text-slate-400">MRP:</span>
                <span class="font-bold text-slate-300 ${isDpMode ? 'line-through text-xs' : 'text-sky-400 font-display text-lg'}" id="mrp-display-${product.id}">
                  ${formatPrice(mrp)}
                </span>
              </div>
              
              <div class="flex items-baseline gap-2 mt-0.5">
                <span class="text-xs text-slate-400 font-semibold">DP Rate:</span>
                <span class="text-xl font-bold text-emerald-400 font-display" id="dp-display-${product.id}">
                  ${formatPrice(dp)}
                </span>
                <span class="text-[10px] text-emerald-300 font-bold bg-emerald-950/70 px-1.5 py-0.5 rounded border border-emerald-800/50">
                  ${marginPercent}% Margin
                </span>
              </div>
            </div>
            
            <button onclick="openProductCustomizer('${product.id}')" title="Test Laser Engraving" class="p-2 rounded-xl bg-slate-800 text-sky-400 hover:bg-sky-950 hover:text-sky-300 border border-slate-700 transition">
              <i data-lucide="sparkles" class="w-4 h-4"></i>
            </button>
          </div>

          <!-- Add to Quote Button -->
          <button onclick="addCardToCart('${product.id}')" class="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50 transition transform active:scale-95">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            <span>Add to Quotation</span>
          </button>
        </div>
      </div>

    </div>
  `;
}

// Card Selection Handlers
const CardSelections = {};

function selectCardVariant(productId, variantIndex) {
  if (!CardSelections[productId]) CardSelections[productId] = { variantIndex: 0, colorIndex: 0 };
  CardSelections[productId].variantIndex = variantIndex;

  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  const buttons = document.querySelectorAll(`.variant-btn-${productId}`);
  buttons.forEach(btn => {
    const idx = parseInt(btn.dataset.index);
    if (idx === variantIndex) {
      btn.className = `variant-btn-${productId} px-2.5 py-1 text-xs rounded-lg border transition font-medium bg-sky-500/20 text-sky-300 border-sky-500/60 shadow-sm`;
    } else {
      btn.className = `variant-btn-${productId} px-2.5 py-1 text-xs rounded-lg border transition font-medium bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700`;
    }
  });

  const variant = product.variants[variantIndex];
  const mrpEl = document.getElementById(`mrp-display-${productId}`);
  const dpEl = document.getElementById(`dp-display-${productId}`);
  
  if (mrpEl) mrpEl.innerText = formatPrice(variant.mrp || variant.price);
  if (dpEl) dpEl.innerText = formatPrice(variant.dpPrice || variant.wholesalePrice);
}

function selectCardColor(productId, colorIndex) {
  if (!CardSelections[productId]) CardSelections[productId] = { variantIndex: 0, colorIndex: 0 };
  CardSelections[productId].colorIndex = colorIndex;

  const product = AppState.products.find(p => p.id === productId);
  if (!product || !product.colors) return;

  const selectedColor = product.colors[colorIndex];

  const buttons = document.querySelectorAll(`.color-btn-${productId}`);
  buttons.forEach(btn => {
    const idx = parseInt(btn.dataset.cindex);
    if (idx === colorIndex) {
      btn.className = `w-6 h-6 rounded-full border-2 transition transform hover:scale-110 shadow-sm border-sky-400 ring-2 ring-sky-400/30 scale-110 color-btn-${productId}`;
    } else {
      btn.className = `w-6 h-6 rounded-full border-2 transition transform hover:scale-110 shadow-sm border-slate-700 color-btn-${productId}`;
    }
  });

  const nameEl = document.getElementById(`color-name-${productId}`);
  if (nameEl) nameEl.innerText = selectedColor.name;
}

function addCardToCart(productId) {
  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  const selection = CardSelections[productId] || { variantIndex: 0, colorIndex: 0 };
  const variant = product.variants[selection.variantIndex] || product.variants[0];
  const color = product.colors && product.colors.length > 0 ? product.colors[selection.colorIndex] : { name: "Stainless Steel", hex: "#cbd5e1" };

  const defaultQty = AppState.pricingMode === 'dp' ? (product.moqBulk || 25) : 1;
  const unitPrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);

  addToCart({
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    layerType: product.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: color.name,
    colorHex: color.hex,
    brandingId: 'none',
    brandingName: 'Plain / Nanobot Finish',
    customText: '',
    quantity: defaultQty,
    unitPrice: unitPrice,
    imageUrl: product.imageUrl,
    bottleStyle: product.bottleStyle
  });

  showToast(`Added ${product.name} (${variant.capacity}) to quotation!`);
}

// Cart System
function addToCart(item) {
  const existingIndex = AppState.cart.findIndex(i => 
    i.productId === item.productId &&
    i.capacity === item.capacity &&
    i.colorHex === item.colorHex &&
    i.brandingId === item.brandingId &&
    i.customText === item.customText
  );

  if (existingIndex > -1) {
    AppState.cart[existingIndex].quantity += item.quantity;
  } else {
    AppState.cart.push(item);
  }

  saveCartToStorage();
}

function updateCartQuantity(index, newQty) {
  if (newQty <= 0) {
    AppState.cart.splice(index, 1);
  } else {
    AppState.cart[index].quantity = newQty;
  }
  saveCartToStorage();
  renderCartDrawer();
}

function removeCartItem(index) {
  AppState.cart.splice(index, 1);
  saveCartToStorage();
  renderCartDrawer();
}

function updateCartBadge() {
  const badge = document.getElementById('cart-badge-count');
  const totalItems = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  if (badge) {
    badge.innerText = totalItems;
    badge.style.display = totalItems > 0 ? 'flex' : 'none';
  }
}

// Product Details Modal
function openProductModal(productId) {
  const product = AppState.products.find(p => p.id === productId);
  if (!product) return;

  AppState.selectedProductForModal = product;
  const modal = document.getElementById('product-modal');
  const modalBody = document.getElementById('product-modal-body');
  if (!modal || !modalBody) return;

  const defaultVariant = product.variants[0];
  const defaultColor = product.colors && product.colors.length > 0 ? product.colors[0] : { name: "Stainless Steel", hex: "#cbd5e1" };
  const isDoubleLayer = product.layerType === 'double_layer' || product.hotHours > 0;

  modalBody.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
      <div class="bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl p-8 flex flex-col items-center justify-center relative border border-slate-800">
        <div class="w-48 h-72 bottle-mockup-wrapper mb-4 flex items-center justify-center" id="modal-bottle-stage">
          ${product.imageUrl ? `
            <img src="${product.imageUrl}" alt="${product.name}" class="max-h-64 max-w-full object-contain drop-shadow-2xl">
          ` : `
            <div class="text-sm text-slate-400 font-bold">${product.name}</div>
          `}
        </div>
        ${product.colors && product.colors.length > 0 ? `
          <div class="flex items-center gap-2">
            ${product.colors.map((c, i) => `
              <button type="button" 
                      onclick="updateModalColor(${i})" 
                      title="${c.name}"
                      style="background-color: ${c.hex};" 
                      class="w-7 h-7 rounded-full border-2 ${i === 0 ? 'border-sky-400 ring-2 ring-sky-400/40' : 'border-slate-700'} modal-color-swatch" 
                      data-cindex="${i}">
              </button>
            `).join('')}
          </div>
          <span class="text-xs text-slate-400 mt-2" id="modal-color-label">${defaultColor.name}</span>
        ` : ''}
      </div>

      <div>
        <div class="flex items-center gap-2 mb-2">
          <span class="text-xs font-mono text-sky-400 px-2 py-0.5 bg-sky-950 rounded border border-sky-800">${product.sku}</span>
          <span class="text-xs font-bold px-2 py-0.5 rounded ${isDoubleLayer ? 'bg-amber-950 text-amber-300 border border-amber-800/40' : 'bg-blue-950 text-blue-300 border border-blue-800/40'}">
            ${isDoubleLayer ? 'Double Layer (Vacuum Insulated)' : 'Single Layer (Fridge Bottle)'}
          </span>
        </div>

        <h2 class="text-2xl font-bold text-white font-display mb-2">${product.name}</h2>
        <p class="text-slate-300 text-sm mb-4 leading-relaxed">${product.description}</p>

        <!-- Technical Specs -->
        <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 mb-5 space-y-2 text-xs">
          <div class="flex justify-between py-1 border-b border-slate-800">
            <span class="text-slate-400">Category Layer</span>
            <span class="text-white font-semibold">${isDoubleLayer ? 'Double Layer Vacuum (24h Cold / 18h Hot)' : 'Single Layer Fast Fridge Chilling'}</span>
          </div>
          <div class="flex justify-between py-1 border-b border-slate-800">
            <span class="text-slate-400">Steel Material Grade</span>
            <span class="text-white font-semibold">${product.steelGrade}</span>
          </div>
          <div class="flex justify-between py-1 border-b border-slate-800">
            <span class="text-slate-400">Lid Mechanism</span>
            <span class="text-white font-semibold">${product.lidType}</span>
          </div>
          <div class="flex justify-between py-1">
            <span class="text-slate-400">Recommended MOQ</span>
            <span class="text-white font-semibold">${product.moqBulk || 25} pcs (DP Wholesale)</span>
          </div>
        </div>

        <!-- Capacity Variant Buttons -->
        <div class="mb-5">
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Select Size Variant:</label>
          <div class="grid grid-cols-3 gap-2" id="modal-variant-options">
            ${product.variants.map((v, idx) => `
              <button onclick="updateModalVariant(${idx})" class="p-2.5 rounded-xl border text-left transition ${idx === 0 ? 'bg-sky-500/20 border-sky-500 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'} modal-var-btn" data-vindex="${idx}">
                <div class="font-bold text-sm">${v.capacity}</div>
                <div class="text-[11px] text-slate-400">MRP: ${formatPrice(v.mrp || v.price)}</div>
                <div class="text-xs text-emerald-400 font-semibold mt-0.5">DP: ${formatPrice(v.dpPrice || v.wholesalePrice)}</div>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Quantity & Add to Cart -->
        <div class="flex items-center gap-4">
          <div class="flex items-center bg-slate-900 border border-slate-700 rounded-xl p-1">
            <button onclick="adjustModalQty(-1)" class="w-8 h-8 rounded-lg bg-slate-800 text-white hover:bg-slate-700 flex items-center justify-center">-</button>
            <input type="number" id="modal-qty-input" value="${AppState.pricingMode === 'dp' ? (product.moqBulk || 25) : 1}" min="1" class="w-14 bg-transparent text-center text-white text-sm font-semibold focus:outline-none">
            <button onclick="adjustModalQty(1)" class="w-8 h-8 rounded-lg bg-slate-800 text-white hover:bg-slate-700 flex items-center justify-center">+</button>
          </div>

          <button onclick="addModalProductToCart()" class="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-sky-950 transition">
            <i data-lucide="shopping-cart" class="w-4 h-4"></i>
            <span>Add to Quotation</span>
          </button>
        </div>

      </div>
    </div>
  `;

  modal.classList.remove('hidden');
  lucide.createIcons();
}

let modalSelectedVarIdx = 0;
let modalSelectedColorIdx = 0;

function updateModalVariant(idx) {
  modalSelectedVarIdx = idx;
  const buttons = document.querySelectorAll('.modal-var-btn');
  buttons.forEach(btn => {
    const vIdx = parseInt(btn.dataset.vindex);
    if (vIdx === idx) {
      btn.className = 'p-2.5 rounded-xl border text-left transition bg-sky-500/20 border-sky-500 text-white modal-var-btn';
    } else {
      btn.className = 'p-2.5 rounded-xl border text-left transition bg-slate-900 border-slate-800 text-slate-300 modal-var-btn';
    }
  });
}

function updateModalColor(idx) {
  modalSelectedColorIdx = idx;
  const product = AppState.selectedProductForModal;
  if (!product || !product.colors) return;
  const color = product.colors[idx];

  const swatches = document.querySelectorAll('.modal-color-swatch');
  swatches.forEach(sw => {
    const cIdx = parseInt(sw.dataset.cindex);
    if (cIdx === idx) {
      sw.className = 'w-7 h-7 rounded-full border-2 border-sky-400 ring-2 ring-sky-400/40 modal-color-swatch';
    } else {
      sw.className = 'w-7 h-7 rounded-full border-2 border-slate-700 modal-color-swatch';
    }
  });

  const label = document.getElementById('modal-color-label');
  if (label) label.innerText = color.name;
}

function adjustModalQty(delta) {
  const input = document.getElementById('modal-qty-input');
  if (!input) return;
  let val = parseInt(input.value) || 1;
  val = Math.max(1, val + delta);
  input.value = val;
}

function addModalProductToCart() {
  const product = AppState.selectedProductForModal;
  if (!product) return;

  const variant = product.variants[modalSelectedVarIdx] || product.variants[0];
  const color = product.colors && product.colors.length > 0 ? product.colors[modalSelectedColorIdx] : { name: "Stainless Steel", hex: "#cbd5e1" };
  const qtyInput = document.getElementById('modal-qty-input');
  const qty = parseInt(qtyInput ? qtyInput.value : 1) || 1;

  const unitPrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);

  addToCart({
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    layerType: product.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: color.name,
    colorHex: color.hex,
    brandingId: 'none',
    brandingName: 'Plain / Nanobot Finish',
    customText: '',
    quantity: qty,
    unitPrice: unitPrice,
    imageUrl: product.imageUrl,
    bottleStyle: product.bottleStyle
  });

  closeModal('product-modal');
  showToast(`Added ${qty}x ${product.name} to your quotation!`);
}

// Live Customizer Studio
function initCustomizer() {
  const modelSelect = document.getElementById('customizer-model-select');
  if (modelSelect) {
    modelSelect.innerHTML = AppState.products.map(p => `
      <option value="${p.id}">${p.name} (${p.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'})</option>
    `).join('');

    modelSelect.value = AppState.customizer.productId;
  }

  renderCustomizerColorSwatches();
  renderCustomizerBrandingOptions();
  renderCustomizerPreview();
}

function openProductCustomizer(productId) {
  if (productId) {
    AppState.customizer.productId = productId;
    const modelSelect = document.getElementById('customizer-model-select');
    if (modelSelect) modelSelect.value = productId;
    
    const prod = AppState.products.find(p => p.id === productId);
    if (prod && prod.colors && prod.colors.length > 0) {
      AppState.customizer.colorHex = prod.colors[0].hex;
      AppState.customizer.colorName = prod.colors[0].name;
    }
  }

  const customizerSection = document.getElementById('customizer-section');
  if (customizerSection) {
    customizerSection.scrollIntoView({ behavior: 'smooth' });
  }

  renderCustomizerColorSwatches();
  renderCustomizerPreview();
}

function renderCustomizerColorSwatches() {
  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const container = document.getElementById('customizer-color-swatches');
  if (!container || !prod || !prod.colors) return;

  container.innerHTML = prod.colors.map((c, i) => `
    <button type="button" 
            onclick="setCustomizerColor('${c.hex}', '${c.name}')" 
            title="${c.name}"
            style="background-color: ${c.hex};" 
            class="w-8 h-8 rounded-full border-2 transition transform hover:scale-110 shadow-sm ${
              AppState.customizer.colorHex === c.hex ? 'border-sky-400 ring-4 ring-sky-400/30 scale-110' : 'border-slate-700'
            }">
    </button>
  `).join('');
}

function renderCustomizerBrandingOptions() {
  const container = document.getElementById('branding-options-container');
  if (!container) return;

  container.innerHTML = BRANDING_OPTIONS.map(opt => `
    <label class="flex items-start gap-3 p-3 rounded-xl border transition cursor-pointer ${
      AppState.customizer.brandingOptionId === opt.id ? 'bg-sky-950/40 border-sky-500 text-white' : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
    }">
      <input type="radio" name="brandingOption" value="${opt.id}" ${AppState.customizer.brandingOptionId === opt.id ? 'checked' : ''} onchange="setBrandingOption('${opt.id}')" class="mt-1 custom-radio">
      <div class="flex-1">
        <div class="flex items-center justify-between">
          <span class="font-bold text-sm text-white">${opt.name}</span>
          <span class="text-xs font-mono ${opt.pricePerUnit === 0 ? 'text-emerald-400' : 'text-sky-400'}">
            ${opt.pricePerUnit === 0 ? 'FREE' : `+${formatPrice(opt.pricePerUnit)}/unit`}
          </span>
        </div>
        <p class="text-xs text-slate-400 mt-0.5">${opt.desc} (Min Qty: ${opt.moq} pcs)</p>
      </div>
    </label>
  `).join('');
}

function setCustomizerColor(hex, name) {
  AppState.customizer.colorHex = hex;
  AppState.customizer.colorName = name;
  renderCustomizerColorSwatches();
  renderCustomizerPreview();
}

function setBrandingOption(optId) {
  AppState.customizer.brandingOptionId = optId;
  renderCustomizerBrandingOptions();
  renderCustomizerPreview();
}

function renderCustomizerPreview() {
  const canvas = document.getElementById('customizer-canvas');
  if (!canvas) return;

  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const text = AppState.customizer.engravingText;

  canvas.innerHTML = `
    <div class="relative w-full h-full flex flex-col items-center justify-center p-4">
      ${prod.imageUrl ? `<img src="${prod.imageUrl}" class="max-h-72 max-w-full object-contain drop-shadow-2xl">` : ''}
      <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <div class="bg-slate-900/80 px-3 py-1 rounded-lg border border-sky-400/50 backdrop-blur-md shadow-xl text-center">
          <div class="font-bold text-xs tracking-widest text-sky-300 font-mono uppercase">${escapeHtml(text)}</div>
          <div class="text-[9px] text-slate-400 font-mono tracking-wider">LASER MARK • SUS 304</div>
        </div>
      </div>
    </div>
  `;
}

function handleCustomizerTextChange(val) {
  AppState.customizer.engravingText = val;
  renderCustomizerPreview();
}

function handleLogoUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    AppState.customizer.logoDataUrl = event.target.result;
    renderCustomizerPreview();
    showToast('Logo uploaded to preview stage!');
  };
  reader.readAsDataURL(file);
}

function removeCustomLogo() {
  AppState.customizer.logoDataUrl = null;
  const input = document.getElementById('logo-upload-input');
  if (input) input.value = '';
  renderCustomizerPreview();
}

function addCustomizerToCart() {
  const prod = AppState.products.find(p => p.id === AppState.customizer.productId) || AppState.products[0];
  const branding = BRANDING_OPTIONS.find(b => b.id === AppState.customizer.brandingOptionId) || BRANDING_OPTIONS[0];
  const variant = prod.variants[0];
  const defaultQty = Math.max(branding.moq || 1, AppState.pricingMode === 'dp' ? (prod.moqBulk || 25) : 1);

  const basePrice = AppState.pricingMode === 'dp' ? (variant.dpPrice || variant.wholesalePrice) : (variant.mrp || variant.price);
  const finalUnitPrice = basePrice + branding.pricePerUnit;

  addToCart({
    productId: prod.id,
    productName: prod.name,
    sku: prod.sku,
    layerType: prod.layerType,
    capacity: variant.capacity,
    mrp: variant.mrp || variant.price,
    dpPrice: variant.dpPrice || variant.wholesalePrice,
    colorName: AppState.customizer.colorName,
    colorHex: AppState.customizer.colorHex,
    brandingId: branding.id,
    brandingName: branding.name,
    customText: AppState.customizer.engravingText,
    logoUrl: AppState.customizer.logoDataUrl,
    quantity: defaultQty,
    unitPrice: finalUnitPrice,
    imageUrl: prod.imageUrl,
    bottleStyle: prod.bottleStyle
  });

  showToast(`Added custom engraved ${prod.name} to Quotation!`);
}

// Cart Drawer & Quotation Generation
function openCartDrawer() {
  renderCartDrawer();
  const drawer = document.getElementById('cart-drawer');
  if (drawer) drawer.classList.remove('translate-x-full');
}

function closeCartDrawer() {
  const drawer = document.getElementById('cart-drawer');
  if (drawer) drawer.classList.add('translate-x-full');
}

function renderCartDrawer() {
  const itemsContainer = document.getElementById('cart-items-container');
  const subtotalEl = document.getElementById('cart-subtotal');
  const discountEl = document.getElementById('cart-discount');
  const totalEl = document.getElementById('cart-total');
  const tierInfoEl = document.getElementById('cart-tier-info');
  if (!itemsContainer) return;

  if (AppState.cart.length === 0) {
    itemsContainer.innerHTML = `
      <div class="py-16 text-center text-slate-500">
        <i data-lucide="shopping-bag" class="w-16 h-16 mx-auto mb-3 text-slate-600"></i>
        <h4 class="text-base font-bold text-slate-300">Your quotation list is empty</h4>
        <p class="text-xs text-slate-400 mt-1">Select Double Layer or Single Layer bottles to generate an instant quote.</p>
      </div>
    `;
    if (subtotalEl) subtotalEl.innerText = formatPrice(0);
    if (discountEl) discountEl.innerText = formatPrice(0);
    if (totalEl) totalEl.innerText = formatPrice(0);
    if (tierInfoEl) tierInfoEl.innerHTML = '';
    lucide.createIcons();
    return;
  }

  const totalUnits = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  let subtotal = AppState.cart.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);

  let currentTier = WHOLESALE_TIERS[0];
  for (let tier of WHOLESALE_TIERS) {
    if (totalUnits >= tier.minQty) currentTier = tier;
  }

  const discountAmount = Math.round(subtotal * (currentTier.discountPercent / 100));
  const finalTotal = subtotal - discountAmount;

  if (tierInfoEl) {
    tierInfoEl.innerHTML = `
      <div class="p-3 bg-sky-950/60 border border-sky-800/60 rounded-xl mb-4 text-xs flex items-center justify-between">
        <div class="flex items-center gap-2">
          <i data-lucide="award" class="w-4 h-4 text-sky-400"></i>
          <span class="text-sky-200 font-semibold">${currentTier.label} (${totalUnits} Total Pcs)</span>
        </div>
        <span class="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded">${currentTier.tag}</span>
      </div>
    `;
  }

  itemsContainer.innerHTML = AppState.cart.map((item, index) => `
    <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 flex gap-4 items-start relative group">
      <div class="w-12 h-20 shrink-0 bg-slate-950 rounded-lg p-1 flex items-center justify-center">
        ${item.imageUrl ? `<img src="${item.imageUrl}" alt="${item.productName}" class="max-h-16 max-w-full object-contain">` : ''}
      </div>

      <div class="flex-1 min-w-0">
        <div class="flex justify-between items-start">
          <h4 class="text-sm font-bold text-white truncate">${item.productName}</h4>
          <button onclick="removeCartItem(${index})" class="text-slate-500 hover:text-red-400 p-1 transition" title="Remove item">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>

        <div class="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
          <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">${item.capacity}</span>
          <span class="text-[11px] ${item.layerType === 'double_layer' ? 'text-amber-400' : 'text-sky-400'}">
            ${item.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'}
          </span>
        </div>

        ${item.customText ? `
          <div class="text-[11px] text-sky-400 mt-1 flex items-center gap-1 font-mono">
            <i data-lucide="type" class="w-3 h-3"></i> Engraving: "${escapeHtml(item.customText)}"
          </div>
        ` : ''}

        <div class="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/80">
          <div class="flex items-center bg-slate-950 border border-slate-800 rounded-lg">
            <button onclick="updateCartQuantity(${index}, ${item.quantity - 1})" class="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-white">-</button>
            <input type="number" value="${item.quantity}" onchange="updateCartQuantity(${index}, parseInt(this.value)||1)" min="1" class="w-12 bg-transparent text-center text-xs text-white font-semibold focus:outline-none">
            <button onclick="updateCartQuantity(${index}, ${item.quantity + 1})" class="w-6 h-6 flex items-center justify-center text-slate-400 hover:text-white">+</button>
          </div>
          <div class="text-right">
            <div class="text-xs text-slate-400 font-mono">${formatPrice(item.unitPrice)} each</div>
            <div class="text-sm font-bold text-white font-display">${formatPrice(item.unitPrice * item.quantity)}</div>
          </div>
        </div>
      </div>
    </div>
  `).join('');

  if (subtotalEl) subtotalEl.innerText = formatPrice(subtotal);
  if (discountEl) discountEl.innerText = `-${formatPrice(discountAmount)}`;
  if (totalEl) totalEl.innerText = formatPrice(finalTotal);

  lucide.createIcons();
}

// Generate WhatsApp Order
function generateWhatsAppOrder() {
  if (AppState.cart.length === 0) {
    showToast('Your quotation list is empty!');
    return;
  }

  const clientName = document.getElementById('client-name')?.value.trim() || 'Client';
  const clientCompany = document.getElementById('client-company')?.value.trim() || '';
  const clientCity = document.getElementById('client-city')?.value.trim() || '';
  const clientNotes = document.getElementById('client-notes')?.value.trim() || '';

  const totalUnits = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  let subtotal = AppState.cart.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);

  let currentTier = WHOLESALE_TIERS[0];
  for (let tier of WHOLESALE_TIERS) {
    if (totalUnits >= tier.minQty) currentTier = tier;
  }

  const discountAmount = Math.round(subtotal * (currentTier.discountPercent / 100));
  const finalTotal = subtotal - discountAmount;

  let msg = `*✨ NANOBOT STAINLESS STEEL BOTTLE QUOTATION / ORDER ✨*\n`;
  msg += `-------------------------------------------\n`;
  msg += `👤 *Client Name:* ${clientName}\n`;
  if (clientCompany) msg += `🏢 *Company / Brand:* ${clientCompany}\n`;
  if (clientCity) msg += `📍 *Delivery Location:* ${clientCity}\n`;
  msg += `📅 *Date:* ${new Date().toLocaleDateString()}\n`;
  msg += `-------------------------------------------\n`;
  msg += `*SELECTED MODELS (MRP & DP PRICING):*\n\n`;

  AppState.cart.forEach((item, i) => {
    const layer = item.layerType === 'double_layer' ? 'Double Layer Vacuum' : 'Single Layer Fridge';
    msg += `${i + 1}. *${item.productName}* [${item.sku}]\n`;
    msg += `   • Category: ${layer}\n`;
    msg += `   • Capacity: ${item.capacity}\n`;
    if (item.mrp) msg += `   • MRP: ${formatPrice(item.mrp)} | DP: ${formatPrice(item.unitPrice)}\n`;
    if (item.customText) msg += `   • Custom Laser Engraving: "${item.customText}"\n`;
    msg += `   • Quantity: ${item.quantity} units @ ${formatPrice(item.unitPrice)}\n`;
    msg += `   • Item Total: ${formatPrice(item.unitPrice * item.quantity)}\n\n`;
  });

  msg += `-------------------------------------------\n`;
  msg += `📦 *Total Quantity:* ${totalUnits} Units\n`;
  msg += `💰 *Subtotal:* ${formatPrice(subtotal)}\n`;
  if (discountAmount > 0) {
    msg += `🎉 *Volume Tier Discount (${currentTier.tag}):* -${formatPrice(discountAmount)}\n`;
  }
  msg += `🏷️ *Estimated Total:* ${formatPrice(finalTotal)} (Excl. Taxes/Freight)\n`;
  
  if (clientNotes) {
    msg += `-------------------------------------------\n`;
    msg += `📝 *Client Notes / Queries:* ${clientNotes}\n`;
  }

  msg += `\n_Generated via Nanobot Digital Catalog & Order Portal_`;

  const waUrl = `https://wa.me/${AppState.whatsappNumber}?text=${encodeURIComponent(msg)}`;
  window.open(waUrl, '_blank');
}

// Download PDF Quotation
function downloadPdfQuotation() {
  if (AppState.cart.length === 0) {
    showToast('Quotation list is empty!');
    return;
  }

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const clientName = document.getElementById('client-name')?.value.trim() || 'Valued Customer';
    const clientCompany = document.getElementById('client-company')?.value.trim() || 'N/A';
    const clientCity = document.getElementById('client-city')?.value.trim() || 'India';

    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, 210, 40, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.text('NANOBOT', 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(56, 189, 248);
    doc.text('STAINLESS STEEL BOTTLE MANUFACTURER', 14, 27);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(9);
    doc.text('Official Quotation / Proforma Estimate', 140, 20);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 140, 26);
    doc.text(`Ref: NB-QT-${Date.now().toString().slice(-6)}`, 140, 32);

    doc.setTextColor(30, 41, 59);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Quotation Prepared For:', 14, 52);
    doc.setFont('helvetica', 'normal');
    doc.text(`Name: ${clientName}`, 14, 58);
    doc.text(`Company: ${clientCompany}`, 14, 64);
    doc.text(`Destination: ${clientCity}`, 14, 70);

    doc.text('Manufacturer / Origin:', 120, 52);
    doc.text('Nanobot Bottling Industries Pvt. Ltd.', 120, 58);
    doc.text('SUS 304 Food Grade Precision Plant', 120, 64);
    doc.text('Web: www.nanobot.in', 120, 70);

    let y = 85;
    doc.setFillColor(241, 245, 249);
    doc.rect(14, y - 6, 182, 9, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text('SN', 16, y);
    doc.text('Model Description & Layer', 28, y);
    doc.text('Size', 100, y);
    doc.text('MRP', 120, y);
    doc.text('DP Rate', 140, y);
    doc.text('Qty', 162, y);
    doc.text('Total', 180, y);

    doc.setFont('helvetica', 'normal');
    y += 8;

    let subtotal = 0;
    let totalQty = 0;

    AppState.cart.forEach((item, idx) => {
      const itemTotal = item.unitPrice * item.quantity;
      subtotal += itemTotal;
      totalQty += item.quantity;

      const layer = item.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer';

      doc.text(`${idx + 1}`, 16, y);
      doc.text(`${item.productName} (${layer})`, 28, y);
      doc.text(`${item.capacity}`, 100, y);
      doc.text(`${item.mrp || item.unitPrice}`, 120, y);
      doc.text(`${item.unitPrice}`, 140, y);
      doc.text(`${item.quantity}`, 162, y);
      doc.text(`${itemTotal}`, 180, y);

      if (item.customText) {
        y += 5;
        doc.setFontSize(8);
        doc.setTextColor(2, 132, 199);
        doc.text(`[Custom Laser Engraving: "${item.customText}"]`, 28, y);
        doc.setFontSize(9);
        doc.setTextColor(15, 23, 42);
      }

      y += 8;
    });

    let currentTier = WHOLESALE_TIERS[0];
    for (let tier of WHOLESALE_TIERS) {
      if (totalQty >= tier.minQty) currentTier = tier;
    }
    const discount = Math.round(subtotal * (currentTier.discountPercent / 100));
    const grandTotal = subtotal - discount;

    y += 6;
    doc.line(14, y, 196, y);
    y += 8;

    doc.setFont('helvetica', 'bold');
    doc.text(`Total Quantity: ${totalQty} Units`, 14, y);
    doc.text(`Subtotal (DP): ${formatPrice(subtotal)}`, 130, y);

    if (discount > 0) {
      y += 6;
      doc.setTextColor(16, 185, 129);
      doc.text(`Bulk Tier Discount (${currentTier.tag}): -${formatPrice(discount)}`, 130, y);
      doc.setTextColor(15, 23, 42);
    }

    y += 8;
    doc.setFontSize(12);
    doc.text(`Net Estimated Total: ${formatPrice(grandTotal)}`, 130, y);

    y += 20;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Terms & Manufacturing Conditions:', 14, y);
    doc.text('1. 100% Virgin SUS 304 Food-Grade Stainless Steel.', 14, y + 5);
    doc.text('2. 1-Year Manufacturer Warranty against vacuum insulation loss and rust.', 14, y + 10);
    doc.text('3. Prices valid for 30 days. GST and shipping freight as applicable.', 14, y + 15);

    doc.save(`Nanobot_Quotation_${Date.now().toString().slice(-4)}.pdf`);
    showToast('PDF Quotation generated and downloaded!');
  } catch (err) {
    console.error('PDF Generation Error:', err);
    window.print();
  }
}

// Share Link
function copyShareableLink() {
  if (AppState.cart.length === 0) {
    showToast('Add items to cart first to generate share link!');
    return;
  }

  const encodedCart = encodeURIComponent(JSON.stringify(AppState.cart));
  const fullUrl = `${window.location.origin}${window.location.pathname}#cart=${encodedCart}`;

  navigator.clipboard.writeText(fullUrl).then(() => {
    showToast('Shareable catalog quote link copied to clipboard!');
  }).catch(() => {
    prompt('Copy your quotation link below:', fullUrl);
  });
}

function checkUrlParamsForCart() {
  if (window.location.hash && window.location.hash.includes('#cart=')) {
    try {
      const raw = decodeURIComponent(window.location.hash.replace('#cart=', ''));
      const parsedCart = JSON.parse(raw);
      if (Array.isArray(parsedCart) && parsedCart.length > 0) {
        AppState.cart = parsedCart;
        saveCartToStorage();
        showToast('Loaded shared quotation selection from link!');
        openCartDrawer();
      }
    } catch (e) {
      console.warn('Failed to parse URL cart parameter');
    }
  }
}

// Side-by-Side Comparison
function toggleCompare(productId) {
  const idx = AppState.comparisonIds.indexOf(productId);
  if (idx > -1) {
    AppState.comparisonIds.splice(idx, 1);
    showToast(`Removed from comparison`);
  } else {
    if (AppState.comparisonIds.length >= 3) {
      showToast(`You can compare up to 3 models at a time!`);
      return;
    }
    AppState.comparisonIds.push(productId);
    showToast(`Added to comparison table`);
  }
  updateComparisonBar();
  renderProductGrid();
}

function updateComparisonBar() {
  const bar = document.getElementById('comparison-bar');
  const count = document.getElementById('compare-count');
  if (!bar || !count) return;

  if (AppState.comparisonIds.length > 0) {
    bar.classList.remove('hidden');
    count.innerText = `${AppState.comparisonIds.length} Model${AppState.comparisonIds.length > 1 ? 's' : ''} Selected`;
  } else {
    bar.classList.add('hidden');
  }
}

function openComparisonModal() {
  const modal = document.getElementById('compare-modal');
  const container = document.getElementById('compare-table-container');
  if (!modal || !container) return;

  const selectedProducts = AppState.products.filter(p => AppState.comparisonIds.includes(p.id));

  if (selectedProducts.length === 0) {
    showToast('Select at least one bottle to compare!');
    return;
  }

  container.innerHTML = `
    <div class="overflow-x-auto">
      <table class="w-full text-sm text-left border-collapse">
        <thead>
          <tr class="border-b border-slate-800">
            <th class="p-4 text-slate-400 font-medium w-44">Specification</th>
            ${selectedProducts.map(p => `
              <th class="p-4 text-center min-w-[200px]">
                <div class="w-24 h-36 mx-auto mb-2 flex items-center justify-center">
                  ${p.imageUrl ? `<img src="${p.imageUrl}" class="max-h-32 object-contain">` : ''}
                </div>
                <div class="font-bold text-white">${p.name}</div>
                <div class="text-xs text-sky-400 font-mono">${p.sku}</div>
              </th>
            `).join('')}
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/60 text-xs">
          <tr>
            <td class="p-3 text-slate-400 font-semibold">Category Layer</td>
            ${selectedProducts.map(p => `<td class="p-3 text-center font-bold ${p.layerType === 'double_layer' ? 'text-amber-400' : 'text-sky-400'}">${p.layerType === 'double_layer' ? 'Double Layer Vacuum' : 'Single Layer Fridge'}</td>`).join('')}
          </tr>
          <tr>
            <td class="p-3 text-slate-400 font-semibold">Steel Material</td>
            ${selectedProducts.map(p => `<td class="p-3 text-center text-slate-200">${p.steelGrade}</td>`).join('')}
          </tr>
          <tr>
            <td class="p-3 text-slate-400 font-semibold">MRP Price</td>
            ${selectedProducts.map(p => `<td class="p-3 text-center font-bold text-slate-300">${formatPrice(p.variants[0].mrp || p.variants[0].price)}</td>`).join('')}
          </tr>
          <tr>
            <td class="p-3 text-slate-400 font-semibold">DP (Dealer Price)</td>
            ${selectedProducts.map(p => `<td class="p-3 text-center text-lg font-bold text-emerald-400">${formatPrice(p.variants[0].dpPrice || p.variants[0].wholesalePrice)}</td>`).join('')}
          </tr>
          <tr>
            <td class="p-3 text-slate-400 font-semibold">Action</td>
            ${selectedProducts.map(p => `
              <td class="p-3 text-center">
                <button onclick="addCardToCart('${p.id}'); closeModal('compare-modal');" class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-semibold text-xs transition">
                  Add to Quote
                </button>
              </td>
            `).join('')}
          </tr>
        </tbody>
      </table>
    </div>
  `;

  modal.classList.remove('hidden');
}

// Admin / Catalog Manager
function openAdminModal() {
  const modal = document.getElementById('admin-modal');
  if (!modal) return;
  renderAdminProductsList();
  modal.classList.remove('hidden');
}

function renderAdminProductsList() {
  const container = document.getElementById('admin-products-list');
  if (!container) return;

  container.innerHTML = AppState.products.map((p, idx) => `
    <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-14 bg-slate-950 rounded p-1 flex items-center justify-center">
          ${p.imageUrl ? `<img src="${p.imageUrl}" class="max-h-12 object-contain">` : ''}
        </div>
        <div>
          <h4 class="font-bold text-white text-sm">${p.name}</h4>
          <span class="text-xs text-sky-400 font-mono">${p.sku}</span> • 
          <span class="text-xs font-semibold ${p.layerType === 'double_layer' ? 'text-amber-400' : 'text-sky-400'}">
            ${p.layerType === 'double_layer' ? 'Double Layer' : 'Single Layer'}
          </span>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <div class="text-right">
          <div class="text-xs text-slate-400">MRP: <span class="text-white font-bold">${formatPrice(p.variants[0].mrp || p.variants[0].price)}</span></div>
          <div class="text-xs text-emerald-400">DP: <span class="font-bold">${formatPrice(p.variants[0].dpPrice || p.variants[0].wholesalePrice)}</span></div>
        </div>
        <button onclick="editProductPricePrompt(${idx})" class="p-2 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-lg text-xs" title="Edit Pricing & Image">
          <i data-lucide="edit-3" class="w-4 h-4"></i>
        </button>
      </div>
    </div>
  `).join('');

  lucide.createIcons();
}

function editProductPricePrompt(idx) {
  const p = AppState.products[idx];
  if (!p) return;

  const newMrp = prompt(`Enter new MRP for ${p.name} in INR:`, p.variants[0].mrp || p.variants[0].price);
  if (newMrp === null) return;

  const newDp = prompt(`Enter new DP (Dealer Price) for ${p.name} in INR:`, p.variants[0].dpPrice || p.variants[0].wholesalePrice);
  if (newDp === null) return;

  const newImg = prompt(`Enter Image path or URL for ${p.name}:`, p.imageUrl || "");

  const mrpVal = parseInt(newMrp);
  const dpVal = parseInt(newDp);

  if (!isNaN(mrpVal) && !isNaN(dpVal)) {
    p.variants[0].mrp = mrpVal;
    p.variants[0].price = mrpVal;
    p.variants[0].dpPrice = dpVal;
    p.variants[0].wholesalePrice = dpVal;
    if (newImg !== null) p.imageUrl = newImg;

    saveProductsToStorage();
    renderAdminProductsList();
    renderProductGrid();
    showToast(`Updated ${p.name} details!`);
  }
}

function handleBulkCatalogImport() {
  const text = document.getElementById('bulk-import-textarea')?.value.trim();
  if (!text) {
    alert('Please paste your catalog rows from Excel or text.');
    return;
  }

  const lines = text.split('\n');
  const importedList = [];

  lines.forEach((line, index) => {
    const cols = line.split('\t').length > 1 ? line.split('\t') : line.split(',');
    if (cols.length >= 4) {
      const name = cols[0].trim();
      const layer = cols[1].toLowerCase().includes('double') ? 'double_layer' : 'single_layer';
      const cap = cols[2].trim() || '1000 ml';
      const mrp = parseInt(cols[3].replace(/[^0-9]/g, '')) || 599;
      const dp = cols[4] ? parseInt(cols[4].replace(/[^0-9]/g, '')) || Math.round(mrp * 0.6) : Math.round(mrp * 0.6);
      const img = cols[5] ? cols[5].trim() : '';

      importedList.push({
        id: `nb-custom-${Date.now()}-${index}`,
        sku: `NB-${layer === 'double_layer' ? 'DL' : 'SL'}-${index + 101}`,
        name: name,
        layerType: layer,
        category: layer === 'double_layer' ? 'vacuum' : 'fridge',
        tagline: `${layer === 'double_layer' ? 'Double Layer Vacuum' : 'Single Layer Stainless Steel'} Bottle`,
        description: `Premium food-grade SUS 304 stainless steel bottle.`,
        steelGrade: "SUS 304 Food Grade",
        insulation: layer === 'double_layer' ? 'Double Layer Vacuum' : 'Single Layer',
        hotHours: layer === 'double_layer' ? 18 : 0,
        coldHours: layer === 'double_layer' ? 24 : 0,
        lidType: "Leakproof SS Cap",
        imageUrl: img,
        isBestseller: index === 0,
        variants: [
          { capacity: cap, mrp: mrp, dpPrice: dp, price: mrp, wholesalePrice: dp, weight: "250g" }
        ],
        colors: [
          { name: "Brushed Steel", hex: "#cbd5e1", textColor: "#111827" },
          { name: "Matte Black", hex: "#1e293b", textColor: "#ffffff" }
        ],
        moqBulk: 25,
        bottleStyle: layer === 'double_layer' ? 'flask' : 'fridge'
      });
    }
  });

  if (importedList.length > 0) {
    AppState.products = importedList;
    saveProductsToStorage();
    renderAdminProductsList();
    renderProductGrid();
    closeModal('admin-modal');
    showToast(`Successfully imported ${importedList.length} products!`);
  } else {
    alert('Could not parse rows. Format: Name, Layer (Double/Single), Capacity, MRP, DP Price');
  }
}

function exportCatalogJSON() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(AppState.products, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `Nanobot_Catalog_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
  showToast('Catalog exported as JSON!');
}

function importCatalogJSON(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    try {
      const imported = JSON.parse(event.target.result);
      if (Array.isArray(imported)) {
        AppState.products = imported;
        saveProductsToStorage();
        renderAdminProductsList();
        renderProductGrid();
        showToast('Successfully imported catalog!');
      }
    } catch (err) {
      alert('Invalid JSON format.');
    }
  };
  reader.readAsText(file);
}

function resetToDefaultCatalog() {
  if (confirm('Reset all products and pricing to factory defaults?')) {
    AppState.products = [...DEFAULT_PRODUCTS];
    localStorage.removeItem('nanobot_custom_products');
    renderAdminProductsList();
    renderProductGrid();
    showToast('Reset catalog to factory defaults.');
  }
}

function showToast(message) {
  const toast = document.getElementById('toast-notification');
  const toastMsg = document.getElementById('toast-message');
  if (!toast || !toastMsg) return;

  toastMsg.innerText = message;
  toast.classList.remove('hidden');
  toast.classList.add('toast-slide-in');

  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3500);
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('hidden');
}

function escapeHtml(text) {
  return text.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
  });
}

function initEventListeners() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.searchQuery = e.target.value.trim();
      renderProductGrid();
    });
  }

  // Pricing Mode Switcher (MRP vs DP Rate)
  const mrpBtn = document.getElementById('btn-mode-mrp');
  const dpBtn = document.getElementById('btn-mode-dp');

  if (mrpBtn && dpBtn) {
    mrpBtn.addEventListener('click', () => {
      AppState.pricingMode = 'mrp';
      mrpBtn.className = 'px-4 py-1.5 rounded-lg text-xs font-bold transition bg-sky-500 text-white shadow-sm';
      dpBtn.className = 'px-4 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition';
      renderProductGrid();
    });

    dpBtn.addEventListener('click', () => {
      AppState.pricingMode = 'dp';
      dpBtn.className = 'px-4 py-1.5 rounded-lg text-xs font-bold transition bg-emerald-600 text-white shadow-sm';
      mrpBtn.className = 'px-4 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition';
      renderProductGrid();
    });
  }

  const currencyToggle = document.getElementById('currency-toggle');
  if (currencyToggle) {
    currencyToggle.addEventListener('click', () => {
      AppState.currency = AppState.currency === 'INR' ? 'USD' : 'INR';
      currencyToggle.innerText = AppState.currency === 'INR' ? '₹ INR' : '$ USD';
      renderProductGrid();
      renderCartDrawer();
      showToast(`Switched currency to ${AppState.currency}`);
    });
  }

  const customizerSelect = document.getElementById('customizer-model-select');
  if (customizerSelect) {
    customizerSelect.addEventListener('change', (e) => {
      openProductCustomizer(e.target.value);
    });
  }
}
