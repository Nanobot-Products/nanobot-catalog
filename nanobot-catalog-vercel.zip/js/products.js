/**
 * Nanobot Official Product Catalog Data
 * Extracted directly from official Nanobot July 2026 Price List & Catalogues
 */

const DEFAULT_PRODUCTS = [
  // ==========================================
  // DOUBLE LAYER (VACUUM INSULATED FLASKS - 18% GST)
  // ==========================================
  {
    id: "nb-dl-therma",
    sku: "NB-DL-TH01",
    name: "Nanobot Therma Vacuum Flask",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "SUS 304 Double Wall Vacuum Flask (24h Cold / 18h Hot)",
    description: "Engineered with true vacuum double-wall insulation and copper reflective shield. Keeps cold 24h or hot 18h with zero outer condensation.",
    steelGrade: "SUS 304 Food Grade (18/8)",
    insulation: "Double Layer Vacuum + Copper Coating",
    hotHours: 18,
    coldHours: 24,
    lidType: "Precision Leakproof SS Cap",
    imageUrl: "images/products/nb-dl-therma.png",
    isBestseller: true,
    variants: [
      { capacity: "350 ml", mrp: 719, dpPrice: 360, price: 719, wholesalePrice: 360 },
      { capacity: "500 ml", mrp: 809, dpPrice: 405, price: 809, wholesalePrice: 405 },
      { capacity: "750 ml", mrp: 1079, dpPrice: 540, price: 1079, wholesalePrice: 540 },
      { capacity: "1000 ml", mrp: 1199, dpPrice: 600, price: 1199, wholesalePrice: 600 }
    ],
    colors: [
      { name: "Plain Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#1a1a1a" },
      { name: "Royal Blue", hex: "#1e3a8a" },
      { name: "Sky Cyan", hex: "#0284c7" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-thermax",
    sku: "NB-DL-TH02",
    name: "Nanobot Thermax Color Series",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Vibrant Premium Matte Color Double Wall Vacuum Flask",
    description: "Thermax offers durable scratch-resistant powder-coated color finishes with all-day temperature retention.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 18,
    coldHours: 24,
    lidType: "Threaded SS Cap with Silicone Gasket",
    imageUrl: "images/products/nb-dl-thermax.png",
    isBestseller: true,
    variants: [
      { capacity: "350 ml", mrp: 799, dpPrice: 400, price: 799, wholesalePrice: 400 },
      { capacity: "500 ml", mrp: 889, dpPrice: 445, price: 889, wholesalePrice: 445 },
      { capacity: "750 ml", mrp: 1169, dpPrice: 585, price: 1169, wholesalePrice: 585 },
      { capacity: "1000 ml", mrp: 1289, dpPrice: 645, price: 1289, wholesalePrice: 645 }
    ],
    colors: [
      { name: "Matte Black", hex: "#18181b" },
      { name: "Lavender", hex: "#c084fc" },
      { name: "Raspberry Pink", hex: "#f43f5e" },
      { name: "Military Olive", hex: "#3f4f34" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-kryo",
    sku: "NB-DL-KR03",
    name: "Nanobot Kryo Double Layer Flask",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Heavy-Duty High Capacity Expedition Flask (Up to 1.8 Litres)",
    description: "Extended capacity double wall vacuum bottle for road trips, corporate desks, and all-day hydration.",
    steelGrade: "SUS 304 Heavy Gauge",
    insulation: "Deep Vacuum Insulated",
    hotHours: 24,
    coldHours: 36,
    lidType: "Insulated Stopper Lid with Drinking Cup",
    imageUrl: "images/products/nb-dl-kryo.png",
    isBestseller: true,
    variants: [
      { capacity: "350 ml", mrp: 699, dpPrice: 350, price: 699, wholesalePrice: 350 },
      { capacity: "500 ml", mrp: 839, dpPrice: 420, price: 839, wholesalePrice: 420 },
      { capacity: "750 ml", mrp: 1039, dpPrice: 520, price: 1039, wholesalePrice: 520 },
      { capacity: "1000 ml", mrp: 1249, dpPrice: 625, price: 1249, wholesalePrice: 625 },
      { capacity: "1500 ml", mrp: 1899, dpPrice: 950, price: 1899, wholesalePrice: 950 },
      { capacity: "1800 ml", mrp: 1999, dpPrice: 1000, price: 1999, wholesalePrice: 1000 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Midnight Black", hex: "#1e293b" }
    ],
    moqBulk: 20
  },
  {
    id: "nb-dl-doro",
    sku: "NB-DL-DO04",
    name: "Nanobot Doro Vacuum Bottle",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Ergonomic Modern Double Wall Hydration Bottle",
    description: "Minimalist silhouette with rolled lip for smooth sipping and long-lasting hot & cold thermal retention.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 18,
    coldHours: 24,
    lidType: "Hermetic SS Screw Cap",
    imageUrl: "images/products/nb-dl-doro.png",
    isBestseller: false,
    variants: [
      { capacity: "500 ml", mrp: 799, dpPrice: 399, price: 799, wholesalePrice: 399 },
      { capacity: "750 ml", mrp: 939, dpPrice: 469, price: 939, wholesalePrice: 469 },
      { capacity: "1000 ml", mrp: 1099, dpPrice: 550, price: 1099, wholesalePrice: 550 }
    ],
    colors: [
      { name: "Satin Plain Steel", hex: "#d1d5db" },
      { name: "Onyx Black", hex: "#111827" },
      { name: "Rose Gold", hex: "#be7c72" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-vepo",
    sku: "NB-DL-VG05",
    name: "Nanobot Vepo Go Slim & Falcon",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Ultra-Slim Double Wall Vacuum Flask for Backpacks & Handbags",
    description: "Compact, space-saving vacuum bottle that fits easily into slim briefcases, handbag pockets, and car holders.",
    steelGrade: "SUS 304 Food Grade",
    insulation: "Slim Vacuum Insulated",
    hotHours: 14,
    coldHours: 20,
    lidType: "Compact Twist Stopper Cap",
    imageUrl: "images/products/nb-dl-vepo.png",
    isBestseller: false,
    variants: [
      { capacity: "500 ml", mrp: 699, dpPrice: 350, price: 699, wholesalePrice: 350 },
      { capacity: "700 ml", mrp: 799, dpPrice: 400, price: 799, wholesalePrice: 400 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" },
      { name: "Cyan", hex: "#06b6d4" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-rover-hiker",
    sku: "NB-DL-RH06",
    name: "Nanobot Rover & Hiker Sports Flask",
    layerType: "double_layer",
    category: "sports",
    tagline: "Active Trekking & Gym Vacuum Flask with Ergonomic Carry Loop",
    description: "Rugged double wall vacuum sports bottle featuring durable loop cap for easy carabiner clip and gym carrying.",
    steelGrade: "SUS 304 High Impact",
    insulation: "Double Layer Vacuum",
    hotHours: 14,
    coldHours: 24,
    lidType: "Sports Carry Loop Handle Cap",
    imageUrl: "images/products/nb-dl-rover.png",
    isBestseller: true,
    variants: [
      { capacity: "500 ml", mrp: 749, dpPrice: 375, price: 749, wholesalePrice: 375 },
      { capacity: "750 ml", mrp: 799, dpPrice: 400, price: 799, wholesalePrice: 400 }
    ],
    colors: [
      { name: "Stealth Black", hex: "#18181b" },
      { name: "Army Olive", hex: "#3f4f34" },
      { name: "Brushed Steel", hex: "#cbd5e1" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-mince",
    sku: "NB-DL-MN07",
    name: "Nanobot Mince Pocket Vacuum Flask",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Ultra-Portable 220ml - 400ml Pocket Thermal Flask",
    description: "Miniature vacuum flask designed for espresso, warm milk, herbal infusions, and compact daily travel.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 12,
    coldHours: 18,
    lidType: "Leakproof Threaded Cap",
    imageUrl: "images/products/nb-dl-mince.png",
    isBestseller: false,
    variants: [
      { capacity: "220 ml", mrp: 529, dpPrice: 265, price: 529, wholesalePrice: 265 },
      { capacity: "400 ml", mrp: 699, dpPrice: 350, price: 699, wholesalePrice: 350 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 30
  },
  {
    id: "nb-dl-orion-gruss",
    sku: "NB-DL-OG08",
    name: "Nanobot Orion, Gruss & Crater",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Executive Textured Vacuum Flask Series",
    description: "Premium tactile powder-coated finish with ergonomic grip geometry for boardroom desks and executive gifting.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 18,
    coldHours: 24,
    lidType: "Precision Insulated Cap",
    imageUrl: "images/products/nb-dl-orion.png",
    isBestseller: false,
    variants: [
      { capacity: "500 ml", mrp: 949, dpPrice: 475, price: 949, wholesalePrice: 475 },
      { capacity: "700 ml", mrp: 1149, dpPrice: 575, price: 1149, wholesalePrice: 575 }
    ],
    colors: [
      { name: "Midnight Black", hex: "#18181b" },
      { name: "Cobalt Blue", hex: "#1d4ed8" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-aura-univa",
    sku: "NB-DL-AU09",
    name: "Nanobot Aura & Univa Vacuum Bottle",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Minimalist Modern Double Wall Office Flask",
    description: "Clean cylindrical vacuum bottle for daily hydration, office tea/coffee, and fresh water.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 14,
    coldHours: 20,
    lidType: "Threaded Stainless Steel Cap",
    imageUrl: "images/products/nb-dl-aura.png",
    isBestseller: false,
    variants: [
      { capacity: "350 ml (Univa)", mrp: 569, dpPrice: 285, price: 569, wholesalePrice: 285 },
      { capacity: "400 ml (Aura)", mrp: 899, dpPrice: 450, price: 899, wholesalePrice: 450 },
      { capacity: "460 ml (Univa)", mrp: 739, dpPrice: 370, price: 739, wholesalePrice: 370 },
      { capacity: "700 ml (Aura)", mrp: 1099, dpPrice: 550, price: 1099, wholesalePrice: 550 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 25
  },
  {
    id: "nb-dl-kettl-carafe",
    sku: "NB-DL-KT10",
    name: "Nanobot Kettl Tabletop Thermal Carafe",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Executive Boardroom & Tabletop Double Wall Thermal Pot",
    description: "Double wall vacuum dispenser carafe with push-lever spout for coffee, tea, conference rooms, and hospitality.",
    steelGrade: "SUS 304 Interior & Exterior",
    insulation: "Thermal Double Wall Carafe",
    hotHours: 24,
    coldHours: 36,
    lidType: "Thumb-Press Spout Stopper",
    imageUrl: "images/products/nb-dl-kettl.png",
    isBestseller: true,
    variants: [
      { capacity: "350 ml", mrp: 899, dpPrice: 450, price: 899, wholesalePrice: 450 },
      { capacity: "500 ml", mrp: 1049, dpPrice: 525, price: 1049, wholesalePrice: 525 },
      { capacity: "750 ml", mrp: 1149, dpPrice: 575, price: 1149, wholesalePrice: 575 },
      { capacity: "1000 ml", mrp: 1249, dpPrice: 625, price: 1249, wholesalePrice: 625 },
      { capacity: "1500 ml", mrp: 1499, dpPrice: 750, price: 1499, wholesalePrice: 750 }
    ],
    colors: [
      { name: "Brushed Satin Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" },
      { name: "Ruby Maroon", hex: "#881337" }
    ],
    moqBulk: 15
  },
  {
    id: "nb-dl-combos",
    sku: "NB-DL-CB11",
    name: "Nanobot Therma & Kettl Gift Combo Sets",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Luxury Corporate Gifting Vacuum Flask + Double Wall SS Cups Sets",
    description: "Executive gift packaging including 1 vacuum bottle with 2, 3, or 4 double-walled stainless steel cups.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Double Layer Vacuum",
    hotHours: 18,
    coldHours: 24,
    lidType: "Insulated Stopper Cap",
    imageUrl: "images/products/nb-dl-combos.png",
    isBestseller: true,
    variants: [
      { capacity: "Therma Duo (Flask + 2 Cups)", mrp: 1049, dpPrice: 525, price: 1049, wholesalePrice: 525 },
      { capacity: "Therma Trio (Flask + 3 Cups)", mrp: 1299, dpPrice: 649, price: 1299, wholesalePrice: 649 },
      { capacity: "Therma Quattro (Flask + 4 Cups)", mrp: 1599, dpPrice: 799, price: 1599, wholesalePrice: 799 },
      { capacity: "Kettl Trio (Kettl + 3 Cups)", mrp: 1449, dpPrice: 725, price: 1449, wholesalePrice: 725 },
      { capacity: "Kettl Quattro (Kettl + 4 Cups)", mrp: 1649, dpPrice: 825, price: 1649, wholesalePrice: 825 }
    ],
    colors: [
      { name: "Corporate Black", hex: "#1a1a1a" },
      { name: "Brushed Steel", hex: "#cbd5e1" }
    ],
    moqBulk: 10
  },
  {
    id: "nb-dl-lunch-therma",
    sku: "NB-DL-LT12",
    name: "Nanobot Lunch Therma & Tiffin Sets",
    layerType: "double_layer",
    category: "vacuum",
    tagline: "Vacuum Insulated Stainless Steel Tiffin Meals & Bento Sets",
    description: "Double wall vacuum insulated food jars that keep curries, rice, and meals piping hot for lunchtime.",
    steelGrade: "SUS 304 Food Grade",
    insulation: "Double Layer Food Jar",
    hotHours: 12,
    coldHours: 12,
    lidType: "Airtight Silicone Sealed Lid",
    imageUrl: "images/products/nb-dl-lunch.png",
    isBestseller: false,
    variants: [
      { capacity: "220 ml Solo", mrp: 699, dpPrice: 350, price: 699, wholesalePrice: 350 },
      { capacity: "330 ml Solo", mrp: 749, dpPrice: 375, price: 749, wholesalePrice: 375 },
      { capacity: "470 ml Solo", mrp: 849, dpPrice: 425, price: 849, wholesalePrice: 425 },
      { capacity: "Duo Set (2x Tiffins + Bag)", mrp: 1799, dpPrice: 900, price: 1799, wholesalePrice: 900 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 15
  },

  // ==========================================
  // SINGLE LAYER (STAINLESS STEEL FRIDGE BOTTLES - 5% GST)
  // ==========================================
  {
    id: "nb-sl-doro",
    sku: "NB-SL-DF01",
    name: "Nanobot Doro Single Layer Fridge Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "SUS 304 Rapid Refrigerator Chilling Steel Bottle",
    description: "The hygienic, unbreakable replacement for plastic bottles. Made from virgin 304 steel for fast cooling in fridge doors.",
    steelGrade: "SUS 304 Virgin Food Safe (18/8)",
    insulation: "Single Layer (Rapid Fridge Chill)",
    hotHours: 0,
    coldHours: 0,
    lidType: "Leakproof Threaded Cap with Silicone Gasket",
    imageUrl: "images/products/nb-sl-doro.png",
    isBestseller: true,
    variants: [
      { capacity: "750 ml", mrp: 359, dpPrice: 162, price: 359, wholesalePrice: 162 },
      { capacity: "1000 ml", mrp: 399, dpPrice: 180, price: 399, wholesalePrice: 180 }
    ],
    colors: [
      { name: "Plain Gloss Steel", hex: "#e5e7eb" },
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-nero",
    sku: "NB-SL-JN02",
    name: "Nanobot Jr. Nero Kids & School Bottle",
    layerType: "single_layer",
    category: "kids",
    tagline: "Featherlight SUS 304 Steel Bottle for School & Kids",
    description: "Lightweight, child-safe single wall stainless steel water bottle with smooth sipping rim.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Easy-Grip Cap with Carry Loop",
    imageUrl: "images/products/nb-sl-nero.png",
    isBestseller: true,
    variants: [
      { capacity: "400 ml", mrp: 299, dpPrice: 135, price: 299, wholesalePrice: 135 },
      { capacity: "600 ml", mrp: 329, dpPrice: 148, price: 329, wholesalePrice: 148 }
    ],
    colors: [
      { name: "Gloss Steel", hex: "#e2e8f0" },
      { name: "Matte Black", hex: "#18181b" },
      { name: "Sky Cyan", hex: "#0284c7" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-twist-energex",
    sku: "NB-SL-TE03",
    name: "Nanobot Twist & Energex Gym Bottle",
    layerType: "single_layer",
    category: "sports",
    tagline: "High-Capacity 800ml - 900ml Sports & Workout Bottle",
    description: "Ergonomic textured grip body engineered for sports hydration, gym workouts, and outdoor cycling.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Sports Cap with Silicone Seal",
    imageUrl: "images/products/nb-sl-twist.png",
    isBestseller: false,
    variants: [
      { capacity: "800 ml (Energex)", mrp: 749, dpPrice: 337, price: 749, wholesalePrice: 337 },
      { capacity: "900 ml (Twist)", mrp: 559, dpPrice: 252, price: 559, wholesalePrice: 252 }
    ],
    colors: [
      { name: "Matte Black", hex: "#18181b" },
      { name: "Brushed Steel", hex: "#cbd5e1" }
    ],
    moqBulk: 40
  },
  {
    id: "nb-sl-vyoma",
    sku: "NB-SL-VY04",
    name: "Nanobot Vyoma Fridge Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Sleek Cylindrical Single Layer Dining & Refrigerator Bottle",
    description: "Classic dining table bottle fitting snugly into all refrigerator door racks for quick cold water.",
    steelGrade: "SUS 304 Virgin Steel",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Stainless Steel Cap",
    imageUrl: "images/products/nb-sl-vyoma.png",
    isBestseller: true,
    variants: [
      { capacity: "750 ml", mrp: 369, dpPrice: 166, price: 369, wholesalePrice: 166 },
      { capacity: "1000 ml", mrp: 419, dpPrice: 189, price: 419, wholesalePrice: 189 }
    ],
    colors: [
      { name: "Mirror Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#111827" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-pico",
    sku: "NB-SL-PC05",
    name: "Nanobot Pico Compact Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "400ml Handbag & Compact Pocket Single Layer Bottle",
    description: "Ultra-compact single wall steel bottle that slips into lunch bags, kids packs, and purses.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Leakproof Threaded Cap",
    imageUrl: "images/products/nb-sl-pico.png",
    isBestseller: false,
    variants: [
      { capacity: "400 ml", mrp: 319, dpPrice: 144, price: 319, wholesalePrice: 144 }
    ],
    colors: [
      { name: "Gloss Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-agua-ace",
    sku: "NB-SL-AA06",
    name: "Nanobot Agua, Ace & Whizzy",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Popular 750ml - 1000ml Single Layer Fridge Bottles",
    description: "All-time popular fridge door bottle collection with threaded leakproof stainless steel tops.",
    steelGrade: "SUS 304 Food Grade",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Precision SS Threaded Cap",
    imageUrl: "images/products/nb-sl-agua.png",
    isBestseller: true,
    variants: [
      { capacity: "750 ml (Ace)", mrp: 399, dpPrice: 180, price: 399, wholesalePrice: 180 },
      { capacity: "750 ml (Agua)", mrp: 389, dpPrice: 175, price: 389, wholesalePrice: 175 },
      { capacity: "750 ml (Whizzy)", mrp: 429, dpPrice: 193, price: 429, wholesalePrice: 193 },
      { capacity: "1000 ml (Agua)", mrp: 399, dpPrice: 180, price: 399, wholesalePrice: 180 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-thar-diamond",
    sku: "NB-SL-TD07",
    name: "Nanobot Thar & Thar Diamond",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Geometric Faceted Textured Single Layer Steel Bottle",
    description: "Faceted diamond-grip design providing modern aesthetics and slip-resistant handling.",
    steelGrade: "SUS 304 High-Tensile Steel",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Diamond Texture SS Cap",
    imageUrl: "images/products/nb-sl-thar.png",
    isBestseller: false,
    variants: [
      { capacity: "750 ml", mrp: 469, dpPrice: 211, price: 469, wholesalePrice: 211 },
      { capacity: "1000 ml", mrp: 549, dpPrice: 247, price: 549, wholesalePrice: 247 }
    ],
    colors: [
      { name: "Diamond Satin Steel", hex: "#cbd5e1" },
      { name: "Matte Jet Black", hex: "#18181b" }
    ],
    moqBulk: 40
  },
  {
    id: "nb-sl-akua",
    sku: "NB-SL-AK08",
    name: "Nanobot Akua Ultra Slim Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Ultra-Slim 500ml - 700ml Single Layer Fridge Bottle",
    description: "Slim profile design engineered for compact fridge door pockets and lightweight carrying.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Leakproof Threaded Cap",
    imageUrl: "images/products/nb-sl-akua.png",
    isBestseller: false,
    variants: [
      { capacity: "500 ml", mrp: 279, dpPrice: 126, price: 279, wholesalePrice: 126 },
      { capacity: "700 ml", mrp: 309, dpPrice: 139, price: 309, wholesalePrice: 139 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-mizu-neer",
    sku: "NB-SL-MN09",
    name: "Nanobot Mizu & Neer Series",
    layerType: "single_layer",
    category: "fridge",
    tagline: "700ml - 800ml Ultra Slim Fridge Bottle",
    description: "Streamlined single wall steel bottle with leakproof seal for daily home and office drinking water.",
    steelGrade: "SUS 304 Food Grade",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Hermetic SS Cap",
    imageUrl: "images/products/nb-sl-neer.png",
    isBestseller: false,
    variants: [
      { capacity: "700 ml", mrp: 309, dpPrice: 139, price: 309, wholesalePrice: 139 },
      { capacity: "800 ml", mrp: 349, dpPrice: 157, price: 349, wholesalePrice: 157 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Midnight Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-sleek",
    sku: "NB-SL-SK10",
    name: "Nanobot Sleek Ultra-Slim Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Compact 300ml - 500ml Single Layer Pocket Steel Bottle",
    description: "Lightweight and narrow body designed for kids backpacks, purses, and quick sips.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "SS Cap with Ring",
    imageUrl: "images/products/nb-sl-sleek.png",
    isBestseller: false,
    variants: [
      { capacity: "300 ml", mrp: 259, dpPrice: 117, price: 259, wholesalePrice: 117 },
      { capacity: "500 ml", mrp: 289, dpPrice: 130, price: 289, wholesalePrice: 130 }
    ],
    colors: [
      { name: "Gloss Steel", hex: "#e2e8f0" },
      { name: "Matte Black", hex: "#18181b" }
    ],
    moqBulk: 50
  },
  {
    id: "nb-sl-sip-mist",
    sku: "NB-SL-SM11",
    name: "Nanobot Sip & Mist Sports Bottle",
    layerType: "single_layer",
    category: "sports",
    tagline: "Dual Function Sports Bottle with Refreshing Mist Sprayer",
    description: "Combines a drinking spout and built-in fine mist sprayer to cool down during sports, cycling, and workouts.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Sip & Mist Dual Trigger Mechanism",
    imageUrl: "images/products/nb-sl-sip-mist.png",
    isBestseller: true,
    variants: [
      { capacity: "750 ml", mrp: 578, dpPrice: 260, price: 578, wholesalePrice: 260 },
      { capacity: "1000 ml", mrp: 638, dpPrice: 287, price: 638, wholesalePrice: 287 }
    ],
    colors: [
      { name: "Cobalt Blue", hex: "#1d4ed8" },
      { name: "Matte Black", hex: "#18181b" },
      { name: "Silver Gloss", hex: "#cbd5e1" }
    ],
    moqBulk: 30
  },
  {
    id: "nb-sl-prisma-neo",
    sku: "NB-SL-PN12",
    name: "Nanobot Prisma & Neo Fridge Bottle",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Textured Multi-Faceted Prism Steel Bottle",
    description: "Contemporary prism facet styling reflecting light with rapid refrigerator chilling performance.",
    steelGrade: "SUS 304 Food Grade",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Leakproof SS Cap",
    imageUrl: "images/products/nb-sl-prisma.png",
    isBestseller: false,
    variants: [
      { capacity: "750 ml", mrp: 399, dpPrice: 180, price: 399, wholesalePrice: 180 },
      { capacity: "1000 ml", mrp: 489, dpPrice: 220, price: 489, wholesalePrice: 220 }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#cbd5e1" },
      { name: "Matte Charcoal", hex: "#27272a" }
    ],
    moqBulk: 40
  },
  {
    id: "nb-sl-oil-dispenser",
    sku: "NB-SL-OD13",
    name: "Nanobot SS Oil Dispenser",
    layerType: "single_layer",
    category: "fridge",
    tagline: "1100ml Pure SUS 304 Kitchen Oil & Liquid Dispenser",
    description: "Food-grade stainless steel kitchen liquid dispenser with non-drip spout for cooking oils and vinegar.",
    steelGrade: "SUS 304 Kitchen Grade",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Drip-Free Pour Spout Cap",
    imageUrl: "images/products/nb-sl-oil.png",
    isBestseller: false,
    variants: [
      { capacity: "1100 ml", mrp: 549, dpPrice: 247, price: 549, wholesalePrice: 247 }
    ],
    colors: [
      { name: "Gloss Plain Steel", hex: "#cbd5e1" }
    ],
    moqBulk: 30
  },
  {
    id: "nb-sl-eco-sets",
    sku: "NB-SL-ES14",
    name: "Nanobot Eco Drink Sets (Mizu / Nero)",
    layerType: "single_layer",
    category: "fridge",
    tagline: "Multi-Pack Stainless Steel Refrigerator Bottle Sets",
    description: "Value bundle packs of 2 or 3 stainless steel bottles for whole families and dining tables.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Layer",
    hotHours: 0,
    coldHours: 0,
    lidType: "Leakproof SS Caps",
    imageUrl: "images/products/nb-sl-eco-sets.png",
    isBestseller: true,
    variants: [
      { capacity: "Mizu Eco Set (700 ml)", mrp: 549, dpPrice: 247, price: 549, wholesalePrice: 247 },
      { capacity: "Nero Eco Set (1000 ml)", mrp: 849, dpPrice: 382, price: 849, wholesalePrice: 382 }
    ],
    colors: [
      { name: "Steel Bundle", hex: "#cbd5e1" },
      { name: "Black Bundle", hex: "#18181b" }
    ],
    moqBulk: 20
  }
];

// Wholesale Volume Discount Tiers Configuration
const WHOLESALE_TIERS = [
  { minQty: 1, maxQty: 9, label: "Retail Tier (MRP)", discountPercent: 0, tag: "MRP Rate" },
  { minQty: 10, maxQty: 49, label: "Dealer Base Tier (DP Rate)", discountPercent: 0, tag: "Dealer Price (DP)" },
  { minQty: 50, maxQty: 199, label: "Corporate Bulk Tier", discountPercent: 10, tag: "10% Extra on DP" },
  { minQty: 200, maxQty: 499, label: "Super Stockist Tier", discountPercent: 15, tag: "15% Extra on DP" },
  { minQty: 500, maxQty: 999999, label: "Factory Direct OEM/ODM", discountPercent: 22, tag: "Best Factory Rate" }
];

const BRANDING_OPTIONS = [
  { id: "none", name: "Plain / Nanobot Factory Finish", pricePerUnit: 0, moq: 1, desc: "Standard unbranded or Nanobot signature logo" },
  { id: "laser", name: "Precision Fiber Laser Engraving", pricePerUnit: 25, moq: 10, desc: "Permanent crisp metallic silver mark, never fades" },
  { id: "uv_print", name: "Full Color UV Digital Print", pricePerUnit: 45, moq: 25, desc: "High-resolution full color photo & gradient printing" },
  { id: "screen_print", name: "Single/Dual Color Screen Print", pricePerUnit: 20, moq: 50, desc: "Cost-effective vibrant solid color printing for large runs" }
];
