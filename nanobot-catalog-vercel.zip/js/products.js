/**
 * Nanobot Official Product Catalog Data
 * Comprehensive collection of Stainless Steel Vacuum Bottles and Single-Wall Fridge Bottles
 */

const DEFAULT_PRODUCTS = [
  // --- VACUUM INSULATED BOTTLES (Double Wall SUS 304) ---
  {
    id: "nb-vac-classic",
    sku: "NB-VC-100",
    name: "Nanobot Classic Vacuum Flask",
    category: "vacuum",
    tagline: "Double-Wall Insulated Daily Commuter Flask",
    description: "Premium double-walled SUS 304 food-grade stainless steel vacuum flask with copper insulation coating. Keeps beverages piping hot for 18 hours or ice-cold for 24 hours without any condensation or sweat.",
    steelGrade: "SUS 304 (18/8) Food Grade",
    insulation: "Double Wall Vacuum + Copper Coating",
    hotHours: 18,
    coldHours: 24,
    lidType: "Leak-Proof Screw Cap with Stainless Steel Accent",
    isBestseller: true,
    isNew: false,
    rating: 4.9,
    reviewsCount: 142,
    variants: [
      { capacity: "500 ml", price: 649, wholesalePrice: 420, weight: "290g", dimensions: "26cm x 6.8cm" },
      { capacity: "750 ml", price: 799, wholesalePrice: 510, weight: "360g", dimensions: "29cm x 7.4cm" },
      { capacity: "1000 ml", price: 949, wholesalePrice: 610, weight: "440g", dimensions: "32cm x 8.1cm" }
    ],
    colors: [
      { name: "Matte Black", hex: "#1a1a1a", textColor: "#ffffff" },
      { name: "Brushed Steel", hex: "#d1d5db", textColor: "#111827" },
      { name: "Midnight Navy", hex: "#1e3a8a", textColor: "#ffffff" },
      { name: "Forest Green", hex: "#14532d", textColor: "#ffffff" },
      { name: "Pearl White", hex: "#f8fafc", textColor: "#0f172a" },
      { name: "Rose Gold", hex: "#be7c72", textColor: "#ffffff" }
    ],
    features: [
      "24 Hours Cold / 18 Hours Hot Retention",
      "Triple-Layer Thermal Lock (Copper Coated)",
      "Zero Condensation & Sweat-Proof Body",
      "100% BPA-Free & Non-Toxic Food Grade 304 Steel",
      "Rust-Proof Electro-Polished Interior",
      "Laser Engraving & UV Printing Compatible"
    ],
    moqBulk: 25,
    bottleStyle: "flask"
  },
  {
    id: "nb-vac-active-sports",
    sku: "NB-VS-200",
    name: "Nanobot HydroActive Sports Flask",
    category: "sports",
    tagline: "High-Flow One-Click Sipper & Ergonomic Carry Loop",
    description: "Designed for athletes, gym-goers, and outdoor adventurers. Features a fast-flow flip-straw sipper lid, anti-slip durable powder coating, and maximum cold retention for all-day workouts.",
    steelGrade: "SUS 304 Inside & Out",
    insulation: "Vacuum Double Wall",
    hotHours: 12,
    coldHours: 24,
    lidType: "One-Touch Flip Straw Lid with Carabiner Loop",
    isBestseller: true,
    isNew: true,
    rating: 4.8,
    reviewsCount: 98,
    variants: [
      { capacity: "650 ml", price: 749, wholesalePrice: 480, weight: "330g", dimensions: "25.5cm x 7.2cm" },
      { capacity: "900 ml", price: 899, wholesalePrice: 580, weight: "410g", dimensions: "28.5cm x 7.8cm" },
      { capacity: "1200 ml", price: 1099, wholesalePrice: 710, weight: "520g", dimensions: "31cm x 8.8cm" }
    ],
    colors: [
      { name: "Stealth Black", hex: "#18181b", textColor: "#ffffff" },
      { name: "Vibrant Cyan", hex: "#0891b2", textColor: "#ffffff" },
      { name: "Crimson Red", hex: "#dc2626", textColor: "#ffffff" },
      { name: "Military Olive", hex: "#3f4f34", textColor: "#ffffff" },
      { name: "Solar Orange", hex: "#ea580c", textColor: "#ffffff" }
    ],
    features: [
      "One-Hand Push Button Flip Straw Lid",
      "Integrated Heavy-Duty Soft Touch Carry Handle",
      "Chunky Powder-Coated Grip that Never Slippes",
      "Wide Mouth fits Large Ice Cubes easily",
      "Fits standard vehicle and bicycle cup holders"
    ],
    moqBulk: 25,
    bottleStyle: "sports"
  },
  {
    id: "nb-vac-sleek-infuser",
    sku: "NB-VI-300",
    name: "Nanobot Sleek Infuser Coffee & Tea Flask",
    category: "vacuum",
    tagline: "Slimline Office Flask with Removable SS Strainer",
    description: "Sophisticated minimalist flask tailored for office desks, corporate meetings, and tea/coffee lovers. Includes a detachable 304 stainless steel tea infuser basket for loose leaves, fruit infusing, or cold brew.",
    steelGrade: "SUS 304 Medical-Grade Stainless Steel",
    insulation: "Ultra-Slim Double Wall Vacuum",
    hotHours: 14,
    coldHours: 20,
    lidType: "Hermetic Twist-Seal Insulated Cap",
    isBestseller: false,
    isNew: true,
    rating: 4.9,
    reviewsCount: 64,
    variants: [
      { capacity: "400 ml", price: 599, wholesalePrice: 390, weight: "250g", dimensions: "22cm x 6.2cm" },
      { capacity: "500 ml", price: 699, wholesalePrice: 450, weight: "280g", dimensions: "24cm x 6.5cm" }
    ],
    colors: [
      { name: "Matte Charcoal", hex: "#27272a", textColor: "#ffffff" },
      { name: "Mocha Brown", hex: "#5c3d2e", textColor: "#ffffff" },
      { name: "Champagne Gold", hex: "#d4af37", textColor: "#111827" },
      { name: "Sakura Pink", hex: "#f472b6", textColor: "#ffffff" },
      { name: "Brushed Steel", hex: "#e5e7eb", textColor: "#111827" }
    ],
    features: [
      "Includes 2-in-1 Removable Fine Mesh Tea/Fruit Strainer",
      "Slim 6.5cm Silhouette fits compact briefcase & backpacks",
      "Scratch-Resistant Matte Finish",
      "Non-Leaching, Preserves Original Coffee & Tea Flavor"
    ],
    moqBulk: 30,
    bottleStyle: "infuser"
  },
  {
    id: "nb-vac-summit-handle",
    sku: "NB-VS-400",
    name: "Nanobot Summit Wide-Mouth Loop Flask",
    category: "vacuum",
    tagline: "Rugged Expedition Bottle with Ergonomic Stainless Steel Handle",
    description: "Heavy-duty outdoor vacuum bottle designed for rugged conditions. Wide mouth allows rapid filling and ice loading, while the reinforced silicone-ring cap prevents leaks even in unpressurized mountain climbs.",
    steelGrade: "SUS 304 Heavy Gauge",
    insulation: "Deep Vacuum Thermal Barrier",
    hotHours: 20,
    coldHours: 28,
    lidType: "Reinforced Swivel Handle Cap with Food-Grade Silicone Seal",
    isBestseller: true,
    isNew: false,
    rating: 5.0,
    reviewsCount: 110,
    variants: [
      { capacity: "750 ml", price: 849, wholesalePrice: 550, weight: "380g", dimensions: "26.5cm x 7.8cm" },
      { capacity: "1000 ml", price: 999, wholesalePrice: 650, weight: "460g", dimensions: "29cm x 8.4cm" },
      { capacity: "1500 ml", price: 1299, wholesalePrice: 840, weight: "620g", dimensions: "33cm x 9.6cm" }
    ],
    colors: [
      { name: "Gunmetal Gray", hex: "#374151", textColor: "#ffffff" },
      { name: "Desert Sand", hex: "#c2b280", textColor: "#111827" },
      { name: "Alpine Teal", hex: "#0d9488", textColor: "#ffffff" },
      { name: "Matte Black", hex: "#0f172a", textColor: "#ffffff" }
    ],
    features: [
      "Massive 28-Hour Chill Performance",
      "55mm Wide Mouth for Full Ice Cubes & Easy Sponge Cleaning",
      "Foldable Stainless Steel Carry Loop",
      "Shock-Absorbing Reinforced Base"
    ],
    moqBulk: 20,
    bottleStyle: "summit"
  },
  {
    id: "nb-vac-kiddo-sipper",
    sku: "NB-VK-500",
    name: "Nanobot Kiddo Care Vacuum Sipper",
    category: "kids",
    tagline: "Child-Safe Vacuum Flask with Soft Straw & Protective Boot",
    description: "Specially engineered for school children. Ultra-lightweight double wall vacuum bottle with child-safe push-button flip lid, food-grade silicone soft straw, drop-proof silicone bumper boot, and adjustable shoulder carry strap.",
    steelGrade: "SUS 304 Antibacterial Polished Interior",
    insulation: "Double Wall Vacuum",
    hotHours: 8,
    coldHours: 16,
    lidType: "Push-Button Pop Straw Lid with Safety Lock",
    isBestseller: false,
    isNew: true,
    rating: 4.9,
    reviewsCount: 78,
    variants: [
      { capacity: "380 ml", price: 549, wholesalePrice: 350, weight: "240g", dimensions: "19cm x 6.8cm" },
      { capacity: "480 ml", price: 629, wholesalePrice: 410, weight: "270g", dimensions: "21cm x 7.0cm" }
    ],
    colors: [
      { name: "Sky Blue & Sunshine", hex: "#38bdf8", textColor: "#ffffff" },
      { name: "Candy Pink", hex: "#f43f5e", textColor: "#ffffff" },
      { name: "Pastel Mint", hex: "#34d399", textColor: "#0f172a" },
      { name: "Lilac Purple", hex: "#a855f7", textColor: "#ffffff" }
    ],
    features: [
      "100% Spill & Leak Proof with Safety Catch Lock",
      "Soft Food-Grade Chew-Resistant Silicone Spout",
      "Includes Detachable Anti-Drop Base Boot & Shoulder Strap",
      "Kid-Friendly Ergonomics & Lightweight Body"
    ],
    moqBulk: 30,
    bottleStyle: "kids"
  },
  {
    id: "nb-vac-tumbler-traveler",
    sku: "NB-VT-600",
    name: "Nanobot Urban Traveler Insulated Tumbler",
    category: "tumbler",
    tagline: "Car Cup Holder Friendly Travel Mug with Dual Sip Lid",
    description: "The ultimate commuting mug for hot coffee or iced brew on the road. Tapered base fits effortlessly in all standard car cup holders. Features splash-proof slider lid and comfort grip.",
    steelGrade: "SUS 304 Double Wall",
    insulation: "Vacuum Insulated",
    hotHours: 10,
    coldHours: 18,
    lidType: "Tritan Splash-Proof Slider Cap (Straw Friendly)",
    isBestseller: true,
    isNew: true,
    rating: 4.8,
    reviewsCount: 160,
    variants: [
      { capacity: "600 ml", price: 699, wholesalePrice: 450, weight: "310g", dimensions: "20cm x 8.5cm" },
      { capacity: "900 ml", price: 849, wholesalePrice: 550, weight: "390g", dimensions: "24cm x 9.0cm" }
    ],
    colors: [
      { name: "Matte Pitch Black", hex: "#171717", textColor: "#ffffff" },
      { name: "Stainless Raw", hex: "#e2e8f0", textColor: "#1e293b" },
      { name: "Cobalt Blue", hex: "#2563eb", textColor: "#ffffff" },
      { name: "Sage Green", hex: "#65a30d", textColor: "#ffffff" },
      { name: "Lavender Mist", hex: "#c084fc", textColor: "#ffffff" }
    ],
    features: [
      "Tapered Base specifically engineered for Car Cup Holders",
      "Dual Drinking Option: Direct Sip or Insert Straw",
      "Keeps Ice Frozen for over 18 Hours",
      "Sweat-Proof & Fits Under Standard Espresso Machines"
    ],
    moqBulk: 25,
    bottleStyle: "tumbler"
  },

  // --- SINGLE-WALL STAINLESS STEEL FRIDGE BOTTLES ---
  {
    id: "nb-fridge-classic",
    sku: "NB-FC-101",
    name: "Nanobot HydroCool Single-Wall Fridge Bottle",
    category: "fridge",
    tagline: "Pure 304 Food-Grade Stainless Steel Fridge Door Bottle",
    description: "The hygienic, unbreakable replacement for plastic fridge bottles. Made from premium food-grade stainless steel that chills quickly inside standard refrigerator door racks. Lightweight, rust-proof, and 100% toxic-free.",
    steelGrade: "SUS 304 (18/8) Virgin Food Grade",
    insulation: "Single Wall (Rapid Fridge Chilling)",
    hotHours: 0,
    coldHours: 0,
    lidType: "Precision Thread Leakproof SS Cap with Silicone Gasket",
    isBestseller: true,
    isNew: false,
    rating: 4.9,
    reviewsCount: 230,
    variants: [
      { capacity: "750 ml", price: 299, wholesalePrice: 175, weight: "170g", dimensions: "25cm x 6.9cm" },
      { capacity: "1000 ml", price: 349, wholesalePrice: 205, weight: "210g", dimensions: "27.5cm x 7.3cm" },
      { capacity: "1200 ml", price: 429, wholesalePrice: 250, weight: "245g", dimensions: "29cm x 7.8cm" }
    ],
    colors: [
      { name: "Mirror Gloss Steel", hex: "#e5e7eb", textColor: "#111827" },
      { name: "Brushed Matte Steel", hex: "#cbd5e1", textColor: "#111827" },
      { name: "Matte Black", hex: "#1e293b", textColor: "#ffffff" },
      { name: "Royal Blue", hex: "#1d4ed8", textColor: "#ffffff" },
      { name: "Crimson Red", hex: "#b91c1c", textColor: "#ffffff" }
    ],
    features: [
      "Ultra-Fast Chilling inside Refrigerator",
      "Slim Profile Engineered for Standard Refrigerator Door Shelves",
      "Zero Plastic Contact - Pure Steel Hydration",
      "100% Leakproof Hermetic Seal Cap",
      "Featherweight yet Extremely Dent-Resistant",
      "BPA Free, Phthalate Free, No Chemical Leaching"
    ],
    moqBulk: 50,
    bottleStyle: "fridge"
  },
  {
    id: "nb-fridge-curve-grip",
    sku: "NB-FC-202",
    name: "Nanobot WaveGrip Ergonomic Fridge Bottle",
    category: "fridge",
    tagline: "Contoured Waistline for Slip-Free Grip & Pouring",
    description: "Ergonomically contoured stainless steel fridge bottle designed for effortless one-handed pouring and handling, especially with cold condensation. Fits securely in gym bags, fridge doors, and dining tables.",
    steelGrade: "SUS 304 High-Tensile Steel",
    insulation: "Single Wall High Conductivity",
    hotHours: 0,
    coldHours: 0,
    lidType: "Ergonomic Easy-Grip SS Cap",
    isBestseller: true,
    isNew: false,
    rating: 4.8,
    reviewsCount: 145,
    variants: [
      { capacity: "750 ml", price: 329, wholesalePrice: 190, weight: "180g", dimensions: "25.5cm x 7.0cm" },
      { capacity: "1000 ml", price: 379, wholesalePrice: 220, weight: "220g", dimensions: "28cm x 7.4cm" }
    ],
    colors: [
      { name: "Brushed Steel", hex: "#d1d5db", textColor: "#111827" },
      { name: "Emerald Green", hex: "#047857", textColor: "#ffffff" },
      { name: "Deep Amethyst", hex: "#6b21a8", textColor: "#ffffff" },
      { name: "Copper Bronze Coat", hex: "#b45309", textColor: "#ffffff" }
    ],
    features: [
      "Ergonomic Waist Curve for Natural Firm Grip",
      "Smooth Rolled Drinking Lip for Comfortable Direct Sipping",
      "Seamless Monobloc Deep-Drawn Steel Body",
      "Dishwasher Safe & Easy Internal Hygiene"
    ],
    moqBulk: 50,
    bottleStyle: "fridge"
  },
  {
    id: "nb-fridge-printed-designer",
    sku: "NB-FP-303",
    name: "Nanobot Palette Designer Printed Fridge Bottle",
    category: "fridge",
    tagline: "Scratch-Proof 3D UV Printed & Matte Colorway Series",
    description: "Vibrant and aesthetic stainless steel fridge bottles finished with high-durability 3D UV textured prints and multi-color gradient coats. Adds elegance to your dining table and kitchen decor.",
    steelGrade: "SUS 304 Food Safe",
    insulation: "Single Wall",
    hotHours: 0,
    coldHours: 0,
    lidType: "Color-Matched Stainless Steel Cap",
    isBestseller: false,
    isNew: true,
    rating: 4.7,
    reviewsCount: 88,
    variants: [
      { capacity: "1000 ml", price: 419, wholesalePrice: 245, weight: "225g", dimensions: "27.5cm x 7.3cm" }
    ],
    colors: [
      { name: "Tropical Flora", hex: "#059669", textColor: "#ffffff" },
      { name: "Geometric Aztec", hex: "#d97706", textColor: "#ffffff" },
      { name: "Nordic Waves", hex: "#0284c7", textColor: "#ffffff" },
      { name: "Midnight Marble", hex: "#334155", textColor: "#ffffff" }
    ],
    features: [
      "High-Adhesion UV Protected Graphic Print",
      "Non-Fading and Scratch-Resistant Exterior",
      "Odour-Free, Rust-Free, Bacteria Resistant",
      "Ideal for Corporate Gifting and Festive Merchandising"
    ],
    moqBulk: 50,
    bottleStyle: "fridge"
  },
  {
    id: "nb-fridge-wide-sports",
    sku: "NB-FS-404",
    name: "Nanobot Sprint Single-Wall Gym Bottle",
    category: "sports",
    tagline: "Lightweight High-Capacity Steel Bottle with Sipper Cap",
    description: "The go-to companion for intense gym workouts, trekking, and daily outdoor cardio. Provides the ruggedness of stainless steel at a feather-light weight with a fast-chug sipper spout.",
    steelGrade: "SUS 304 High Impact",
    insulation: "Single Wall",
    hotHours: 0,
    coldHours: 0,
    lidType: "Quick-Chug Sports Spout Lid with Silicone Dust Cover",
    isBestseller: false,
    isNew: true,
    rating: 4.8,
    reviewsCount: 67,
    variants: [
      { capacity: "750 ml", price: 349, wholesalePrice: 205, weight: "185g", dimensions: "24.5cm x 7.2cm" },
      { capacity: "1000 ml", price: 399, wholesalePrice: 235, weight: "225g", dimensions: "27.5cm x 7.6cm" }
    ],
    colors: [
      { name: "Matte Jet Black", hex: "#18181b", textColor: "#ffffff" },
      { name: "Cobalt Blue", hex: "#1e40af", textColor: "#ffffff" },
      { name: "Titanium Silver", hex: "#e2e8f0", textColor: "#1e293b" },
      { name: "Neon Lime Accent", hex: "#84cc16", textColor: "#1e293b" }
    ],
    features: [
      "Ultra-Light for Cycling, Trekking, and Gym Racks",
      "One-Finger Flip Lock Spout for Rapid Hydration",
      "Wide Neck for Easy Cleaning & Ice Refill",
      "Durable Electrostatic Powder Coating"
    ],
    moqBulk: 40,
    bottleStyle: "sports"
  },
  {
    id: "nb-fridge-mini-school",
    sku: "NB-FM-505",
    name: "Nanobot Junior Single-Wall School Bottle",
    category: "kids",
    tagline: "Compact 500ml Steel Bottle with Protective Base & Cap",
    description: "Compact, sturdy stainless steel bottle tailored for school backpacks, kids lunch bags, and quick hydration. Easy to open, hygienic, and completely free from micro-plastics.",
    steelGrade: "SUS 304 Baby-Safe Grade",
    insulation: "Single Wall",
    hotHours: 0,
    coldHours: 0,
    lidType: "Flip-Top Sipper with Easy Grip Ring",
    isBestseller: false,
    isNew: false,
    rating: 4.8,
    reviewsCount: 92,
    variants: [
      { capacity: "500 ml", price: 279, wholesalePrice: 165, weight: "145g", dimensions: "20cm x 6.5cm" },
      { capacity: "650 ml", price: 319, wholesalePrice: 185, weight: "165g", dimensions: "22.5cm x 6.7cm" }
    ],
    colors: [
      { name: "Aqua Blue", hex: "#0284c7", textColor: "#ffffff" },
      { name: "Berry Pink", hex: "#e11d48", textColor: "#ffffff" },
      { name: "Sunny Yellow", hex: "#eab308", textColor: "#1f2937" },
      { name: "Mint Green", hex: "#10b981", textColor: "#ffffff" }
    ],
    features: [
      "Featherlight 145g Weight ideal for school bags",
      "100% Food-Grade Steel replacing harmful plastic",
      "Drop-Proof rounded bottom rim",
      "Name Tag engraving area on bottle neck"
    ],
    moqBulk: 50,
    bottleStyle: "kids"
  },
  {
    id: "nb-vac-carafe-thermo",
    sku: "NB-VC-700",
    name: "Nanobot Grandeur Vacuum Carafe Pot",
    category: "vacuum",
    tagline: "Large-Volume Push-Button Tabletop Dispenser & Coffee Pot",
    description: "Heavy-capacity double-wall vacuum carafe for homes, conference rooms, hotels, and executive dining. Holds temperature for 24 hours with a press-and-pour thumb lever.",
    steelGrade: "SUS 304 Interior + Exterior",
    insulation: "Heavy Double Wall Thermal Shield",
    hotHours: 24,
    coldHours: 36,
    lidType: "Thumb-Press Dispenser Spout with Heat-Lock Stopper",
    isBestseller: false,
    isNew: true,
    rating: 4.9,
    reviewsCount: 52,
    variants: [
      { capacity: "1500 ml", price: 1199, wholesalePrice: 780, weight: "720g", dimensions: "26cm x 13.5cm" },
      { capacity: "2000 ml", price: 1449, wholesalePrice: 920, weight: "860g", dimensions: "29cm x 14.2cm" }
    ],
    colors: [
      { name: "Brushed Satin Steel", hex: "#e2e8f0", textColor: "#1e293b" },
      { name: "Onyx Matte Black", hex: "#18181b", textColor: "#ffffff" },
      { name: "Champagne Pearl", hex: "#fef08a", textColor: "#1e293b" },
      { name: "Ruby Maroon", hex: "#881337", textColor: "#ffffff" }
    ],
    features: [
      "Press-to-Pour Thumb Lever for Controlled Splash-Free Pouring",
      "Extraordinary 24h Hot / 36h Cold Heat Retention",
      "Ergonomic Stay-Cool Beechwood Finish Handle",
      "Wide Opening for Easy Hand Wash & Ice Refills"
    ],
    moqBulk: 15,
    bottleStyle: "carafe"
  }
];

// Wholesale Volume Discount Tiers Configuration
const WHOLESALE_TIERS = [
  { minQty: 1, maxQty: 9, label: "Sample / Retail Tier", discountPercent: 0, tag: "Retail" },
  { minQty: 10, maxQty: 49, label: "Small Business / Reseller", discountPercent: 20, tag: "20% OFF" },
  { minQty: 50, maxQty: 199, label: "Corporate Gifting & Wholesale", discountPercent: 32, tag: "32% OFF" },
  { minQty: 200, maxQty: 499, label: "Bulk Distributor Tier", discountPercent: 40, tag: "40% OFF" },
  { minQty: 500, maxQty: 999999, label: "Factory Direct OEM/ODM", discountPercent: 48, tag: "Best Factory Rate" }
];

// Custom Branding Pricing Config
const BRANDING_OPTIONS = [
  { id: "none", name: "Plain / Nanobot Factory Finish", pricePerUnit: 0, moq: 1, desc: "Standard unbranded or Nanobot signature logo" },
  { id: "laser", name: "Precision Laser Engraving", pricePerUnit: 25, moq: 10, desc: "Permanent crisp metallic silver mark, never fades" },
  { id: "uv_print", name: "Full Color UV Digital Print", pricePerUnit: 45, moq: 25, desc: "High-resolution full color photo & gradient printing" },
  { id: "screen_print", name: "Single/Dual Color Screen Print", pricePerUnit: 20, moq: 50, desc: "Cost-effective vibrant solid color printing for large runs" },
  { id: "custom_color", name: "Custom Pantone Powder Coat + Logo", pricePerUnit: 60, moq: 200, desc: "Custom brand Pantone shell color with gift packaging" }
];
