# 🍾 Nanobot - Stainless Steel Bottle Digital Catalog & Quotation Portal

A modern, interactive digital product showcase and order/quotation portal built for **Nanobot** (Stainless Steel Vacuum Bottle & Fridge Bottle Manufacturers).

---

## 🌟 Key Features

1. **Complete Factory Catalog**:
   - **Double-Wall Vacuum Insulated Flasks**: 24h Cold / 18h Hot temperature retention, copper thermal lock, leakproof caps.
   - **Single-Wall Stainless Steel Fridge Bottles**: Rapid fridge chilling, 100% food-grade SUS 304, ergonomic grip.
   - **Sports, Kids, Tumblers & Tabletop Carafes**: Full range of hydration models.
   - Dynamic capacity selector (350ml to 2000ml) & real-time metallic color swatch switcher.

2. **Interactive Live Laser Customizer**:
   - Live visual simulation of custom branding / fiber laser engraving on the bottle body.
   - Allows typing company names, custom text, or uploading logos (PNG/SVG).

3. **Retail vs. Wholesale / Bulk Tier Pricing**:
   - Instant toggle between single-piece retail pricing and volume discount wholesale tiers (20% to 48% OFF).

4. **1-Click Ordering & Quotation Sharing**:
   - **WhatsApp Order Generator**: Creates a formatted message with selected models, SKUs, colors, quantities, laser engraving details, and estimated total ready to send to your sales desk.
   - **Instant PDF Quotation / Proforma Invoice**: Generates official branded PDF quotation with itemized table, specs, and conditions directly in the browser.
   - **Shareable Link**: Encodes the configured quotation cart into a shareable URL to send to prospective clients.

5. **Side-by-Side Model Comparison**:
   - Compare up to 3 bottle models on steel grade, thermal hours, lid mechanism, capacities, and pricing.

6. **Admin Catalog Management**:
   - Built-in portal to edit model prices, update wholesale rates, export/import JSON catalogs, or add new bottles.

---

## 🚀 How to Run Locally

### Option 1: Double-Click
Simply double-click `index.html` in your file explorer to open it in any web browser!

### Option 2: Run with Python Server
Open terminal in the project directory and run:
```bash
python server.py
```
This starts a local server at `http://localhost:8080` and opens your browser automatically.

---

## 🌐 How to Host & Get a Public Shareable Link for Your Customers

Since this is built with zero backend dependencies, you can host it for free in seconds:

### 1. Free Hosting on Netlify (Drag & Drop - 30 seconds):
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop the `nanobot-catalog` folder onto the web page.
3. You will immediately get a live link like `https://nanobot-bottles.netlify.app` that you can share with all your consumers!

### 2. Free Hosting on GitHub Pages:
1. Push this folder to a GitHub repository (e.g. `github.com/your-name/nanobot-catalog`).
2. Go to **Settings** > **Pages** > Select `main` branch > Click **Save**.
3. Your link will be live at `https://your-username.github.io/nanobot-catalog/`.

### 3. Free Hosting on Vercel:
1. Run `npx vercel` or import your GitHub repository into [Vercel](https://vercel.com).
